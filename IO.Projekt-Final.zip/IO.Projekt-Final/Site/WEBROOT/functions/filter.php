<?php
    // common profanity filter
    require('../config/filter_profanity.php');

    // custom replacement filter
    require('../config/filter_custom.php');

    function Filter($Input) {
        global $Profanity;
        global $Dictionary;
        foreach ($Profanity as $Badword) {
            $Escape = preg_quote($Badword, '/');
            $Regex = '/' . $Escape . '/';
            
            $Input = preg_replace_callback($Regex, function($Matches) {
                return str_repeat('#', strlen($Matches[0]));
            }, $Input);
        }
        $Output = str_replace(array_keys($Dictionary), array_values($Dictionary), $Input);
        return $Output;
    }
    function Filter64($Input64) {
        global $Profanity;
        global $Dictionary;
        $Input = base64_decode($Input64);
        foreach ($Profanity as $Badword) {
            $Escape = preg_quote($Badword, '/');
            $Regex = '/' . $Escape . '/';
            
            $Input = preg_replace_callback($Regex, function($Matches) {
                return str_repeat('#', strlen($Matches[0]));
            }, $Input);
        }
        $Output = str_replace(array_keys($Dictionary), array_values($Dictionary), $Input);
        $Output64 = base64_encode($Output);
        return $Output64;
    }
?>