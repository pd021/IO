<?php
function GenerateCSRF() {
    $Token = bin2hex(random_bytes(32));

    $_SESSION['CSRF'] = $Token;
    return $Token;
}

function CheckCSRF($CSRFSource = 'post') {
    if ($CSRFSource == 'post' && isset($_SESSION['CSRF']) && isset($_POST['CSRF'])) {
        return $_SESSION['CSRF'] === $_POST['CSRF'];
    }
    if ($CSRFSource == 'get' && isset($_SESSION['CSRF']) && isset($_GET['CSRF'])) {
        return $_SESSION['CSRF'] === $_GET['CSRF'];
    }
    
    return false;
}
?>