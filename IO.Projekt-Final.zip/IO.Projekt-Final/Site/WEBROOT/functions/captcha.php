<?php
function GenerateCaptchaImage() {
    error_reporting(0);
    session_start();
    $CaptchaLenght = 4;
    $FontSizeMin = 20;
    $FontSizeMax = 40;
    $MaxDeviation = 10; # [%]
    $Alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    
    $Fonts = array();
    $FontFiles = scandir('../assets/fonts/');
    foreach($FontFiles as $FontFile){
        if(pathinfo($FontFile, PATHINFO_EXTENSION) == 'ttf' || pathinfo($FontFile, PATHINFO_EXTENSION) == 'otf'){
            $Fonts[] = "../assets/fonts/".$FontFile;
        }
    }

    $CaptchaSolution = "";
    for($i = 0; $i < $CaptchaLenght; $i++){
        $CaptchaSolution = $CaptchaSolution.$Alphabet[random_int(0, strlen($Alphabet) - 1)];
    }
    $_SESSION['captcha'] = $CaptchaSolution;

    #tworzy pusty przezroczysty obraz 400x100
    #nawet jeśli użyje się pustego .png to GD czasami ma problemy z kanałem alfa i doda czarne tło
    #ten sposób zawsze działa poprawnie
    $Image = imagecreatetruecolor(400, 100);
    imagealphablending($Image, false);
    $Transparency = imagecolorallocatealpha($Image, 0, 0, 0, 127);
    imagefill($Image, 0, 0, $Transparency);
    imagesavealpha($Image, true);

    for($i = 0; $i < $CaptchaLenght; $i++){
        $RandomAngle = random_int(-50, 50);
        $RandomColor = imagecolorallocate($Image, random_int(0, 255), random_int(0, 255), random_int(0, 255));
        $RandomSize = random_int($FontSizeMin, $FontSizeMax);
        $RandomFont = $Fonts[random_int(0, count($Fonts) - 1)];
        //$RandomFont = "../assets/fonts/arial.ttf";
        $Letter = $CaptchaSolution[$i];
        #zmienne dodające losowy dryft w poziomie i pionie, bo czemu nie :)
        $DeviationX = (1 - ($MaxDeviation / 100)) + (random_int(0, $MaxDeviation) / 100);
        $DeviationY = (1 - ($MaxDeviation / 100)) + (random_int(0, $MaxDeviation) / 100);

        $TextBox = imagettfbbox($RandomSize, $RandomAngle, $RandomFont, $Letter);

        imagettftext($Image, $RandomSize, $RandomAngle,
                (imagesx($Image)-($TextBox[4]-$TextBox[0])) * ($i + 1) / ($CaptchaLenght + 1) * $DeviationX,
                (imagesy($Image)-($TextBox[3]-$TextBox[6])+$RandomSize)/2 * $DeviationY,
                $RandomColor, $RandomFont, $Letter);
    }
    header('Content-Type: image/jpeg');
    imagepng($Image);
    imagedestroy($Image);
    exit();
}
?>