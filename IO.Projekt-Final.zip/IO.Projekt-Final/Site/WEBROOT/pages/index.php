<?php
//not logged in deflector
session_start();

if (!isset($_SESSION['login'])) {
    header("Location: /pages/login.php");
    exit();
}

header("Location: /pages/home.php");
?>