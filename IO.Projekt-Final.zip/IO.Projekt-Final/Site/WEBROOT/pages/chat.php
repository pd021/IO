<?php
    // if not logged in - redirect to login - also dissallow update calls
    session_start();
    if (!isset($_SESSION['login'])) {
        header("Location: /pages/login.php");
        exit();
    }

    // import CSRF utility
    require("../functions/csrf.php");

    // import filter
    require("../functions/filter.php");

    // import chat config
    require("../config/chat.php");

    // logout
    require("../functions/logout.php");
    if(isset($_POST['logout'])) {
        // CSRF check
        if(!CheckCSRF()){
            header("Location: /pages/home.php");
            exit();
        }

        // logout
        Logout();
        exit();
    }

    // database lookups
    if(!(isset($_SESSION['error']) && $_SESSION['error'] == "Wystąpił błąd serwera, spróbój ponownie później.")){ 
        try {
            require("../config/db.php");
            $DB = new PDO("mysql:host=$DBhost;dbname=$DBname", $DBuser, $DBpass);
            $DB -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // ban checks
            $Querry = $DB -> prepare("SELECT level, permaban, ban, active, ircbanned, CASE WHEN ban IS NULL THEN 0 ELSE 1 END AS isbanned FROM users WHERE login = :login");
            $Querry -> bindParam(':login', $_SESSION['login']);
            $Querry -> execute();
            $Record = $Querry -> fetch(PDO::FETCH_ASSOC);
            $IRCBanned = $Record['ircbanned'];

            // is permabanned?
            if($Record['permaban'] != 0) {
                Logout("Konto zostało pernamentnie zbanowane!");
                $DB = null;
                exit();
            }

            // is regular ban or deactivated?
            if($Record['active'] != 1) {
                if(!empty($Record['ban'])) {
                    Logout("Konto jest zbanowane do ".$Record['ban'].".");
                } else {
                    Logout("Konto zostało deaktywowane!");
                }
                $DB = null;
                exit();
            }

            // should the admin panel option be shown?
            if($Record['level'] >= 100) {$Elevated = true;} else {$Elevated = false;}
            $Userlevel = $Record['level'];

            // UPDATE call
            if(isset($_GET['update']) && isset($_GET['update']) == 1) {
                if(empty($_GET['latest'])){
                    header('Content-Type: application/json');
                    echo json_encode(['new' => false, 'error' => 'missing date parameter']);
                    exit();
                }
                            
                $LatestID = filter_input(INPUT_GET, 'latest', FILTER_SANITIZE_STRING);
                $Update = $DB -> prepare("SELECT irclog.ID, CASE WHEN irclog.deleted = 0 THEN irclog.message ELSE 'IFJFREFDVEVE' END AS message, irclog.timestamp, irclog.deleted, users.username AS username, users.external_id AS external_id, CASE WHEN users.level >= 1000 THEN 'darkgreen' WHEN users.level >= 500 THEN 'red' WHEN users.level >= 100 THEN 'yellow' ELSE 'gray' END AS color, CASE WHEN irclog.deleted = true THEN false WHEN users.login = :login THEN true WHEN :level > users.level THEN true ELSE false END AS can_delete FROM irclog JOIN users ON irclog.sender = users.login HAVING ID > :latest ORDER BY ID DESC LIMIT :limit");
                $Update -> bindParam(':login', $_SESSION['login']);
                $Update -> bindParam(':level', $Userlevel);
                $Update -> bindParam(':latest', $LatestID, PDO::PARAM_INT);
                $Update -> bindParam(':limit', $MaxMessagesInUpdate, PDO::PARAM_INT);
                $Update -> execute();
                $LatestMessages = $Update -> fetchAll(PDO::FETCH_ASSOC);

                // no new messages
                if(empty($LatestMessages)) {
                    header('Content-Type: application/json');
                    echo json_encode(['new' => false]);
                    exit();
                }

                header('Content-Type: application/json');
                echo json_encode(['new' => true, 'msg' => $LatestMessages]);
                exit();
            }

            // SEND call
            if(isset($_GET['send']) && isset($_GET['send']) == 1) {
                $SendSuccess = true;
                // security checks  - login check already done above
                if(!CheckCSRF('get') || $IRCBanned || empty($_GET['body'])){
                    $SendSuccess = false;
                    header('Content-Type: application/json');
                    echo json_encode(['ok' => $SendSuccess]);
                    exit();
                }

                // send to db
                $MSGBody = Filter64(filter_input(INPUT_GET, 'body', FILTER_SANITIZE_STRING));
                $Messages = $DB -> prepare("INSERT INTO irclog (sender, timestamp, message) VALUES (:login, NOW(), :body)");
                $Messages -> bindParam(':login', $_SESSION['login']);
                $Messages -> bindParam(':body', $MSGBody);
                $Messages -> execute();
                $DB = null;
                header('Content-Type: application/json');
                echo json_encode(['ok' => $SendSuccess]);
                exit();
            }

            // "delete" message
            if (isset($_GET['delete']) && $_GET['delete'] == 1) {
                // CSRF check
                if(!CheckCSRF('get')){
                    header("Location: /pages/chat.php");
                    exit();
                }

                $MID = filter_input(INPUT_GET, 'mid', FILTER_SANITIZE_STRING);
                $MSG2Delete = $DB -> prepare("SELECT irclog.*, users.level AS level FROM irclog JOIN users ON irclog.sender = users.login WHERE ID = :mid");
                $MSG2Delete -> bindParam(':mid', $MID, PDO::PARAM_INT);
                $MSG2Delete -> execute();
                $MSGRecord = $MSG2Delete -> fetch(PDO::FETCH_ASSOC);

                if (($Elevated && $MSGRecord['level'] < $Userlevel) || $MSGRecord['sender'] == $_SESSION['login']) {
                    $MSG2Delete = $DB -> prepare("UPDATE irclog SET deleted = 1 WHERE ID = :mid");
                    $MSG2Delete -> bindParam(':mid', $MID, PDO::PARAM_INT);
                    $MSG2Delete -> execute();
                }

                $DB = null;
                header("Location: /pages/chat.php");
                exit();
            }

            // Get last N old messages
            $Messages = $DB -> prepare("SELECT irclog.*, users.username AS username, users.external_id AS external_id, users.level AS level FROM irclog JOIN users ON irclog.sender = users.login ORDER BY ID DESC LIMIT :limit");
            $Messages -> bindParam(':limit', $LastNMessages, PDO::PARAM_INT);
            $Messages -> execute();
            
        } catch (PDOException $e) {
            $_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
            //$_SESSION['error'] = $e;
            $DB = null;
            header("Location: /pages/chat.php");
            exit();
        }
    }
    

    //generate CSRF token
    $CSRFToken = GenerateCSRF();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="login panel">
        <link rel="icon" href="/assets/favicon64.ico" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/assets/style_common.css">
        <link rel="stylesheet" href="/assets/style_chat.css">
        <meta http-equiv="Cache-Control" content="max-age=3600">
        <title>Chat</title>
        <script>
            function closeError() {
                var popup = document.getElementById('error-popup');
                popup.style.display = 'none';
            }
            function htmlspecialchars(string) {
                if (typeof string !== 'string') {return string;}
                const CharsMap = {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#039;'
                };

                return string.replace(/[&<>"']/g, function(match) { return CharsMap[match]; });
            }
            function getCSRFToken() {
                const csrfInput = document.querySelector('form.logout input[name="CSRF"]');
                return csrfInput.value;
            }
            function removeLastMessages(count) {
                const chatWindow = document.getElementById('chat-window');
                var messages = chatWindow.getElementsByClassName('message');
                
                const numberOfMessages = messages.length;
                count = Math.min(count, numberOfMessages);

                for (let i = 0; i < count; i++) {
                    chatWindow.removeChild(messages[messages.length - 1]);
                }
            }
            function updateChat() {
                const chatWindow = document.getElementById('chat-window');
                var messages = chatWindow.getElementsByClassName('message');
                var lastMessage = messages[messages.length - 1];
                var msgIdSpan = lastMessage.querySelector('#msgid');
                var LatestID = parseInt(msgIdSpan.textContent || msgIdSpan.innerText);
                
                // Rewrite last 10 messages
                LatestID -= 10;
                removeLastMessages(10);

                var UpdateURL = `/pages/chat.php?update=1&latest=${LatestID}`;
                fetch(UpdateURL)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Błąd sieci: ' + response.statusText);
                    }
                    return response.json();
                })
                .then(data => {
                    if(data.new == false) {return;}

                    data.msg.reverse();
                    data.msg.forEach(message => {
                        var messageDiv = document.createElement('div');
                        messageDiv.className = 'message';
                        if(message.deleted == true) {
                            messageDiv.innerHTML = `<span class="msgdate">&lt;${message.timestamp}&gt;</span><a href="/pages/profile.php?uid=${message.external_id}"><span class="msguser" style="color:${message.color};">${htmlspecialchars(message.username)}: </span></a><span class="msgbodydeleted">Wiadomość została usunięta.</span><span id="msgid" style="display:none;">${message.ID}</span>`;
                        }
                        else if (message.can_delete == true) {
                            messageDiv.innerHTML = `<span class="msgdate">&lt;${message.timestamp}&gt;</span><a href="/pages/profile.php?uid=${message.external_id}"><span class="msguser" style="color:${message.color};">${htmlspecialchars(message.username)}: </span></a><span class="msgbody">${htmlspecialchars(decodeURIComponent(escape(atob(message.message))))}</span><a href="/pages/chat.php?delete=1&mid=${message.ID}&CSRF=${getCSRFToken()}"><span class="msgdelete">Usuń</span></a><span id="msgid" style="display:none;">${message.ID}</span>`;
                        } else {
                            messageDiv.innerHTML = `<span class="msgdate">&lt;${message.timestamp}&gt;</span><a href="/pages/profile.php?uid=${message.external_id}"><span class="msguser" style="color:${message.color};">${htmlspecialchars(message.username)}: </span></a><span class="msgbody">${htmlspecialchars(decodeURIComponent(escape(atob(message.message))))}</span><span id="msgid" style="display:none;">${message.ID}</span>`;
                        }

                        chatWindow.appendChild(messageDiv);
                    });

                    chatWindow.scrollTop = chatWindow.scrollHeight;
                })
            }
            function sendMessage() {
                const MsgBox = document.getElementById('msgbox');
                MessageBody = btoa(unescape(encodeURIComponent(MsgBox.value)));
                MsgBox.value = '';

                CSRF = getCSRFToken();
                var SendURL = `/pages/chat.php?send=1&body=${MessageBody}&CSRF=${CSRF}`;
                fetch(SendURL);
                
                setTimeout(() => {
                    updateChat();
                }, 250);
                return;
            }

            // Enter -> Send
            document.addEventListener('keydown', function(event) {if (event.key === 'Enter') {sendMessage();}});

            // Focus on newest message
            window.addEventListener('load', function() {
                const chatWindow = document.getElementById('chat-window');
                chatWindow.scrollTop = chatWindow.scrollHeight;
            });

            // Always check for updates every 3 sec
            const CyclicUpdate = setInterval(updateChat, 2000);
        </script>
    </head>
    <body>
        <nav class="menu-bar">
            <a href="/pages/forum.php"><div class="menu-item">Forum</div></a>
            <a href="/pages/shop.php"><div class="menu-item">Sklep</div></a>
            <a href="/pages/settings.php"><div class="menu-item">Profil</div></a>
            <?php
                if($Elevated) {
                    echo '<a href="/pages/admin.php"><div class="menu-item">Aministracja</div></a>';
                }
            ?>
            <a href="/pages/home.php" style="position: absolute; right: 9vw;"><div class="menu-item">Strona domowa</div></a>
            <form action="chat.php" method="post" class="logout">
                <input type="hidden" name="logout" value="1">
                <input type="hidden" name="CSRF" value="<?php echo $CSRFToken;?>">
                <input type="submit" id="logout-button" value="Wyloguj się">
            </form>
        </nav>

        <div id="chat-window-container">
            <div id="chat-window">
                <?php
                    try {
                        for($i = 0; $i < $LastNMessages; $i++) {
                            $Message = $Messages -> fetch(PDO::FETCH_ASSOC);
                            $MessageLog[] = $Message;
                        }

                        $MessageLog = array_reverse($MessageLog);

                        foreach ($MessageLog as $Msg) {
                            if(empty($Msg['ID'])) {continue;}
                            switch (true) {
                                case $Msg['level'] >= 1000:
                                    $UserColor = 'darkgreen';
                                    break;
                                case $Msg['level'] >= 500:
                                    $UserColor = 'red';
                                    break;
                                case $Msg['level'] >= 100:
                                    $UserColor = 'yellow';
                                    break;
                                default:
                                    $UserColor = 'gray';
                                    break;
                            }
                            echo '<div class="message">';
                            echo '<span class="msgdate">'.htmlspecialchars('<'.$Msg['timestamp'].'>', ENT_QUOTES, 'UTF-8').'</span>';
                            echo '<a href="/pages/profile.php?uid='.$Msg['external_id'].'"><span class="msguser" style="color:'.$UserColor.';">'.htmlspecialchars($Msg['username'].': ', ENT_QUOTES, 'UTF-8').'</span></a>';
                            
                            if ($Msg['deleted'] == 0) {
                                echo '<span class="msgbody">'.htmlspecialchars(base64_decode($Msg['message']), ENT_QUOTES, 'UTF-8').'</span>';
                            } else {
                                echo '<span class="msgbodydeleted">Wiadomość została usunięta.</span>';
                            }
                            
                            if ((($Elevated && $Msg['level'] < $Userlevel) || $Msg['sender'] == $_SESSION['login']) && $Msg['deleted'] == 0) {
                                echo '<a href="/pages/chat.php?delete=1&mid='.$Msg['ID'].'&CSRF='.$CSRFToken.'"><span class="msgdelete">Usuń</span></a>';
                            }

                            echo '<span id="msgid" style="display:none;">'.$Msg['ID'].'</span>';

                            echo '</div>';
                        }
                    } catch (PDOException $e) {
                        $_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
                        //$_SESSION['error'] = $e;
                        $DB = null;
                        header("Location: /pages/chat.php");
                        exit();
                    }
                    $DB = null;
                ?>
            </div>
            <?php 
                if(!$IRCBanned) {
                    echo '<div id="send-window">';
                    echo '<input type="text" id="msgbox" placeholder="Wiadomość">';
                    echo '<button id="msgsend" onclick="sendMessage()">Wyślij</button>';
                    echo '</div>';
                }
            ?>
        </div>
        
        <?php
            // error message
            if(!empty($_SESSION['error'])) {
                echo "<div id=\"error-popup\">";
                echo "<button class=\"error-close\" onclick=\"closeError()\">x</button>";
                echo "<p id=\"error-message\">" . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . "</p>";
                echo "</div>";
                unset($_SESSION['error']);
            }
        ?>

    </body>
</html>