<?php
    // if not logged in - redirect to login
    session_start();
    if (!isset($_SESSION['login'])) {
        header("Location: /pages/login.php");
        exit();
    }

    // generate captcha on demand
    if(isset($_GET['captcha'])) {
        require("../functions/captcha.php");
        GenerateCaptchaImage();
        exit();
    }

    // import CSRF utility
    require("../functions/csrf.php");

    // import filter
    require("../functions/filter.php");

    // import config
    require("../config/shop.php");

    // logout
    require("../functions/logout.php");
    if(isset($_POST['logout'])) {
        // CSRF check
        if(!CheckCSRF()){
            header("Location: /pages/shop.php");
            exit();
        }

        // logout
        Logout();
        exit();
    }
   

    // database lookups
    if(!(isset($_SESSION['error']) && $_SESSION['error'] === "Wystąpił błąd serwera, spróbój ponownie później.")){ 
        try {
            require("../config/db.php");
            $DB = new PDO("mysql:host=$DBhost;dbname=$DBname", $DBuser, $DBpass);
            $DB -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $Querry = $DB -> prepare("SELECT users.*, CASE WHEN ban IS NULL THEN 0 ELSE 1 END AS isbanned FROM users WHERE login = :login");
            $Querry -> bindParam(':login', $_SESSION['login']);
            $Querry -> execute();
            $CurrentUser = $Querry -> fetch(PDO::FETCH_ASSOC);

            // is permabanned?
            if($CurrentUser['permaban'] != 0) {
                Logout("Konto zostało pernamentnie zbanowane!");
                $DB = null;
                exit();
            }

            // is regular ban or deactivated?
            if($CurrentUser['active'] != 1) {
                if(!empty($CurrentUser['ban'])) {
                    Logout("Konto jest zbanowane do ".$CurrentUser['ban'].".");
                } else {
                    Logout("Konto zostało deaktywowane!");
                }
                $DB = null;
                exit();
            }

            // should the admin panel option be shown?
            if($CurrentUser['level'] >= 100) {$Elevated = true;} else {$Elevated = false;}



            // add new trade offer
            if(isset($_POST['edit']) && $_POST['edit'] == 0) {
                // CSRF check
                if(!CheckCSRF()){
                    $_SESSION['error'] = 'Błąd formularza! Spróbój ponownie.';
                    header("Location: /pages/shop.php");
                    exit();
                }

                $Title = base64_encode(Filter(filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING)));
                $Body = base64_encode(Filter(filter_input(INPUT_POST, 'body', FILTER_SANITIZE_STRING)));
                $TradeInsert = $DB -> prepare("INSERT INTO trades (creator, created_date, title, body) VALUES (:login, NOW(), :title, :body)");
                $TradeInsert -> bindParam(':login', $CurrentUser['login']);
                $TradeInsert -> bindParam(':title', $Title);
                $TradeInsert -> bindParam(':body', $Body);
                $TradeInsert -> execute();
                
                $TradeID = $DB -> lastInsertId();

                // add files to db if present
                if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
                    if ($_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
                        $_SESSION['error'] = "Wystąpił błąd podczas przesyłania plików!";
                        $DB = null;
                        header("Location: /pages/shop.php");
                        exit();
                    }
                    // Get the file details
                    $MediaFileTMP = $_FILES['photo']['tmp_name'];
                    $MediaFileTMPSize = $_FILES['photo']['size'];

                    // check extension
                    $FileInfo = finfo_open(FILEINFO_MIME_TYPE); 
                    $MediaFileTMPExt = finfo_file($FileInfo, $MediaFileTMP);
                    finfo_close($FileInfo);

                    // Allowed image types
                    $ExtWhitelist = [
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/svg+xml' => 'svg',
                        'image/gif' => 'gif'
                    ];

                    // check extension is allowed and file is < 4MB
                    if (array_key_exists($MediaFileTMPExt, $ExtWhitelist) && @getimagesize($MediaFileTMP) && $MediaFileTMPSize <= 4 * 1024 * 1024) {
                        // Read the file content
                        $MediaFileData = file_get_contents($MediaFileTMP);

                        // upload to db
                        $MediaInsert = $DB -> prepare("INSERT INTO media (uploaded_by, uploaded_on, data, extension) VALUES (:login, NOW(), :data, :ext)");
                        $MediaInsert -> bindParam(':login', $_SESSION['login']); // by design uploaded by person editing the profile
                        $MediaInsert -> bindParam(':data', $MediaFileData, PDO::PARAM_LOB);
                        $MediaInsert -> bindParam(':ext', $ExtWhitelist[$MediaFileTMPExt]);
                        $MediaInsert -> execute();

                        $MediaID = $DB -> lastInsertId();

                        // link photo to trade offer
                        $MediaLink = $DB -> prepare("INSERT INTO mediaINtrades (trade_id, media_id) VALUES (:tid, :mid)");
                        $MediaLink -> bindParam(':tid', $TradeID); // by design uploaded by person editing the profile
                        $MediaLink -> bindParam(':mid', $MediaID);
                        $MediaLink -> execute();

                    } else {
                        $_SESSION['error'] = "Niedozwolony format lub rozmiar pliku (max. 4MB)!";
                        $DB = null;
                        header("Location: /pages/shop.php");
                        exit();
                    }
                }
                $DB = null;
                header("Location: /pages/shop.php");
                exit();
            }

            // edit trade request
            if (isset($_POST['edit']) && $_POST['edit'] == 1 && isset($_GET['tid']) && is_numeric($_GET['tid'])) {
                // CSRF check
                if(!CheckCSRF()){
                    $_SESSION['error'] = 'Błąd formularza! Spróbój ponownie.';
                    header("Location: /pages/shop.php");
                    exit();
                }

                // permission check - only author or higher can edit / delete
                $TID = filter_input(INPUT_GET, 'tid', FILTER_SANITIZE_STRING);
                $PermissionLookup = $DB -> prepare("SELECT users.*, trades.*, mediaINtrades.media_id FROM trades JOIN users ON trades.creator = users.login LEFT JOIN mediaINtrades ON mediaINtrades.trade_id = trades.ID WHERE trades.ID = :tid");
                $PermissionLookup -> bindParam(':tid', $TID);
                $PermissionLookup -> execute();
                $TradeUser = $PermissionLookup -> fetch(PDO::FETCH_ASSOC);

                if(!($TradeUser['creator'] == $CurrentUser['login'] || ($TradeUser['level'] < $CurrentUser['level'] && $CurrentUser['level'] >= 100))) {
                    $_SESSION['error'] = 'Nie posiadasz wystarczających uprawnień!';
                    header("Location: /pages/shop.php?tid=".$TID);
                    exit();
                }

                // delete process
                if(isset($_POST['delete']) && $_POST['delete'] == 1) {
                    if($TradeUser['state'] == "DONE") {
                        $_SESSION['error'] = 'Nie można usunąć ukończonej transakcji!';
                        header("Location: /pages/shop.php?tid=".$TID);
                        exit();
                    }

                    // delete offer photos
                    $Eraser = $DB -> prepare("DELETE FROM media WHERE media_id IN (SELECT media_id FROM mediaINoffers WHERE offer_id IN (SELECT ID FROM offers WHERE trade_id = :tid))");
                    $Eraser -> bindParam(':tid', $TID);
                    $Eraser -> execute();

                    // delete media links
                    $Eraser = $DB -> prepare("DELETE FROM mediaINoffers WHERE offer_id IN (SELECT ID FROM offers WHERE trade_id = :tid)");
                    $Eraser -> bindParam(':tid', $TID);
                    $Eraser -> execute();
                    
                    // delete offers
                    $Eraser = $DB -> prepare("DELETE FROM offers WHERE trade_id IN (SELECT ID FROM trades WHERE ID = :tid)");
                    $Eraser -> bindParam(':tid', $TID);
                    $Eraser -> execute();

                    // delete trade photo
                    $Eraser = $DB -> prepare("DELETE FROM media WHERE media_id IN (SELECT media_id FROM mediaINtrades WHERE trade_id = :tid)");
                    $Eraser -> bindParam(':tid', $TID);
                    $Eraser -> execute();

                    // delete trade media link
                    $Eraser = $DB -> prepare("DELETE FROM mediaINtrades WHERE trade_id = :tid");
                    $Eraser -> bindParam(':tid', $TID);
                    $Eraser -> execute();

                    // delete trade
                    $Eraser = $DB -> prepare("DELETE FROM trades WHERE ID = :tid");
                    $Eraser -> bindParam(':tid', $TID);
                    $Eraser -> execute();

                    $DB = null;
                    header("Location: /pages/shop.php");
                    exit();
                }

                if($TradeUser['state'] == "DONE") {
                    $_SESSION['error'] = 'Nie można edytować ukończonej transakcji!';
                    header("Location: /pages/shop.php?tid=".$TID);
                    exit();
                }

                // add new media to DB
                if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
                    if ($_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
                        $_SESSION['error'] = "Wystąpił błąd podczas przesyłania plików!";
                        $DB = null;
                        header("Location: /pages/shop.php");
                        exit();
                    }
                    // Get the file details
                    $MediaFileTMP = $_FILES['photo']['tmp_name'];
                    $MediaFileTMPSize = $_FILES['photo']['size'];

                    // check extension
                    $FileInfo = finfo_open(FILEINFO_MIME_TYPE); 
                    $MediaFileTMPExt = finfo_file($FileInfo, $MediaFileTMP);
                    finfo_close($FileInfo);

                    // Allowed image types
                    $ExtWhitelist = [
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/svg+xml' => 'svg',
                        'image/gif' => 'gif'
                    ];

                    // check extension is allowed and file is < 4MB
                    if (array_key_exists($MediaFileTMPExt, $ExtWhitelist) && @getimagesize($MediaFileTMP) && $MediaFileTMPSize <= 4 * 1024 * 1024) {
                        // Read the file content
                        $MediaFileData = file_get_contents($MediaFileTMP);

                        // upload to db
                        $MediaInsert = $DB -> prepare("INSERT INTO media (uploaded_by, uploaded_on, data, extension) VALUES (:login, NOW(), :data, :ext)");
                        $MediaInsert -> bindParam(':login', $_SESSION['login']); // by design uploaded by person editing the profile
                        $MediaInsert -> bindParam(':data', $MediaFileData, PDO::PARAM_LOB);
                        $MediaInsert -> bindParam(':ext', $ExtWhitelist[$MediaFileTMPExt]);
                        $MediaInsert -> execute();

                        $NewMediaID = $DB -> lastInsertId();
                        $OldMediaID = $TradeUser['media_id'];

                        // link photo to trade offer
                        $MediaLink = $DB -> prepare("UPDATE mediaINtrades SET media_id = :mid WHERE trade_id = :tid");
                        $MediaLink -> bindParam(':tid', $TradeUser['ID']); // by design uploaded by person editing the profile
                        $MediaLink -> bindParam(':mid', $NewMediaID);
                        $MediaLink -> execute();

                        // delete old media
                        $Querry = $DB -> prepare("DELETE FROM media WHERE media_id = :id");
                        $Querry -> bindParam(':id', $OldMediaID);
                        $Querry -> execute();
                    } else {
                        $_SESSION['error'] = "Niedozwolony format lub rozmiar pliku (max. 4MB)!";
                        $DB = null;
                        header("Location: /pages/shop.php");
                        exit();
                    }
                }

                // update text + reset state
                $Title = base64_encode(Filter(filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING)));
                $Body = base64_encode(Filter(filter_input(INPUT_POST, 'body', FILTER_SANITIZE_STRING)));
                $Update = $DB -> prepare("UPDATE trades SET editor = :login, edit_date = NOW(), title = :title, body = :body, state = 'OPEN' WHERE ID = :tid");
                $Update -> bindParam(':login', $_SESSION['login']);
                $Update -> bindParam(':title', $Title);
                $Update -> bindParam(':body', $Body);
                $Update -> bindParam(':tid', $TradeUser['ID']);
                $Update -> execute();

                // reset agreements
                $Update = $DB -> prepare("UPDATE offers SET state = 'OPEN' WHERE trade_id = :tid");
                $Update -> bindParam(':tid', $TradeUser['ID']);
                $Update -> execute();
            }

            // add trade response offer
            if(isset($_POST['addoffer']) && $_POST['addoffer'] == 1) {
                // CSRF check
                if(!CheckCSRF()){
                    $_SESSION['error'] = 'Błąd formularza! Spróbój ponownie.';
                    header("Location: /pages/shop.php");
                    exit();
                }

                $TID = filter_input(INPUT_GET, 'tid', FILTER_SANITIZE_STRING);

                // captcha check
                if($_POST['captcha'] !== $_SESSION['captcha']){
                    $_SESSION['error'] = "Nieprawidłowy rozwiązanie captcha!";
                    header("Location: /pages/shop.php?tid=" . $TID);
                    exit();
                }

                $Body = base64_encode(Filter(filter_input(INPUT_POST, 'body', FILTER_SANITIZE_STRING)));
                $OfferInsert = $DB -> prepare("INSERT INTO offers (trade_id, creator, created_date, body) VALUES (:tid, :login, NOW(), :body)");
                $OfferInsert -> bindParam(':login', $CurrentUser['login']);
                $OfferInsert -> bindParam(':tid', $TID);
                $OfferInsert -> bindParam(':body', $Body);
                $OfferInsert -> execute();

                $NewOfferID = $DB -> lastInsertId();

                // add new media to DB
                if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
                    if ($_FILES['photo']['error'] !== UPLOAD_ERR_OK) {
                        $_SESSION['error'] = "Wystąpił błąd podczas przesyłania plików!";
                        $DB = null;
                        header("Location: /pages/shop.php");
                        exit();
                    }
                    // Get the file details
                    $MediaFileTMP = $_FILES['photo']['tmp_name'];
                    $MediaFileTMPSize = $_FILES['photo']['size'];

                    // check extension
                    $FileInfo = finfo_open(FILEINFO_MIME_TYPE); 
                    $MediaFileTMPExt = finfo_file($FileInfo, $MediaFileTMP);
                    finfo_close($FileInfo);

                    // Allowed image types
                    $ExtWhitelist = [
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/svg+xml' => 'svg',
                        'image/gif' => 'gif'
                    ];

                    // check extension is allowed and file is < 4MB
                    if (array_key_exists($MediaFileTMPExt, $ExtWhitelist) && @getimagesize($MediaFileTMP) && $MediaFileTMPSize <= 4 * 1024 * 1024) {
                        // Read the file content
                        $MediaFileData = file_get_contents($MediaFileTMP);

                        // upload to db
                        $MediaInsert = $DB -> prepare("INSERT INTO media (uploaded_by, uploaded_on, data, extension) VALUES (:login, NOW(), :data, :ext)");
                        $MediaInsert -> bindParam(':login', $_SESSION['login']); // by design uploaded by person editing the profile
                        $MediaInsert -> bindParam(':data', $MediaFileData, PDO::PARAM_LOB);
                        $MediaInsert -> bindParam(':ext', $ExtWhitelist[$MediaFileTMPExt]);
                        $MediaInsert -> execute();

                        $NewMediaID = $DB -> lastInsertId();

                        // link photo to trade offer
                        $MediaLink = $DB -> prepare("INSERT INTO mediaINoffers (media_id, offer_id) VALUES (:mid, :oid)");
                        $MediaLink -> bindParam(':oid', $NewOfferID); // by design uploaded by person editing the profile
                        $MediaLink -> bindParam(':mid', $NewMediaID);
                        $MediaLink -> execute();

                    } else {
                        $_SESSION['error'] = "Niedozwolony format lub rozmiar pliku (max. 4MB)!";
                        $DB = null;
                        header("Location: /pages/shop.php");
                        exit();
                    }
                }
            }

            // delete offer
            if(isset($_GET['offerdelete']) && $_GET['offerdelete'] == 1) {
                // CSRF check
                if(!CheckCSRF('get')){
                    $_SESSION['error'] = 'Błąd formularza! Spróbój ponownie.';
                    header("Location: /pages/shop.php");
                    exit();
                }

                // permission lookup
                $OID = filter_input(INPUT_GET, 'oid', FILTER_SANITIZE_STRING);
                $Lookup = $DB -> prepare("SELECT offers.*, users.*, trades.ID AS TID, trades.offer_id AS OID, trades.state AS state FROM offers JOIN users ON offers.creator = users.login JOIN trades ON trades.ID = offers.trade_id WHERE offers.ID = :oid");
                $Lookup -> bindParam(':oid', $OID);
                $Lookup -> execute();
                $OfferUser = $Lookup -> fetch(PDO::FETCH_ASSOC);

                if(($CurrentUser['login'] == $OfferUser['creator'] || ($OfferUser['level'] < $CurrentUser['level'] && $CurrentUser['level'] >= 100)) && $OfferUser['state'] != 'DONE' || $CurrentUser['level'] >= 1000) {
                    if($OfferUser['ID'] == $OfferUser['OID']) {
                        $ResetProgress = $DB -> prepare("UPDATE trades SET state = 'OPEN', offer_id = NULL WHERE ID = :tid");
                        $ResetProgress -> bindParam(':tid', $OfferUser['TID']);
                        $ResetProgress -> execute();
                    }
                    
                    // delete photo
                    $Eraser = $DB -> prepare("DELETE FROM media WHERE media_id IN (SELECT media_id FROM mediaINoffers WHERE offer_id = :oid)");
                    $Eraser -> bindParam(':oid', $OID);
                    $Eraser -> execute();

                    // delete photo link
                    $Eraser = $DB -> prepare("DELETE FROM mediaINoffers WHERE offer_id = :oid");
                    $Eraser -> bindParam(':oid', $OID);
                    $Eraser -> execute();

                    // delete offer
                    $Eraser = $DB -> prepare("DELETE FROM offers WHERE ID = :oid");
                    $Eraser -> bindParam(':oid', $OID);
                    $Eraser -> execute();

                } else {
                    $_SESSION['error'] = 'Nie masz wystarczających uprawnień!';
                    header("Location: /pages/shop.php?tid=".$OfferUser['TID']);
                    exit();
                }

                header("Location: /pages/shop.php?tid=".$OfferUser['TID']);
                $DB = null;
                exit();
            }

            // agreement processing
            if(isset($_GET['offeraccept']) && $_GET['offeraccept'] == 1) {
                if(!CheckCSRF('get')){
                    $_SESSION['error'] = 'Błąd formularza! Spróbój ponownie.';
                    header("Location: /pages/shop.php");
                    exit();
                }

                // permission lookup
                $OID = filter_input(INPUT_GET, 'oid', FILTER_SANITIZE_STRING);
                $Lookup = $DB -> prepare("SELECT offers.*, users.*, trades.ID AS TID, trades.state AS state, trades.creator AS tcreator FROM offers JOIN users ON offers.creator = users.login JOIN trades ON trades.ID = offers.trade_id WHERE offers.ID = :oid");
                $Lookup -> bindParam(':oid', $OID);
                $Lookup -> execute();
                $OfferUser = $Lookup -> fetch(PDO::FETCH_ASSOC);

                if (($CurrentUser['login'] == $OfferUser['tcreator'] || $CurrentUser['level'] >= 1000) && $OfferUser['state'] == 'OPEN') {
                    // trade selects an offer
                    $Selector = $DB -> prepare("UPDATE trades SET state = 'HALF', offer_id = :oid WHERE ID = :tid");
                    $Selector -> bindParam(':oid', $OID);
                    $Selector -> bindParam(':tid', $OfferUser['TID']);
                    $Selector -> execute();
                } 
                else if (($CurrentUser['login'] == $OfferUser['creator'] || $CurrentUser['level'] >= 1000) && $OfferUser['state'] == 'HALF') {
                    // final accept
                    $Selector = $DB -> prepare("UPDATE trades SET state = 'DONE' WHERE ID = :tid");
                    $Selector -> bindParam(':tid', $OfferUser['TID']);
                    $Selector -> execute();
                } else {
                    $_SESSION['error'] = 'Nie masz wystarczających uprawnień!';
                    header("Location: /pages/shop.php?tid=".$OfferUser['TID']);
                    exit();
                }

                header("Location: /pages/shop.php?tid=".$OfferUser['TID']);
                $DB = null;
                exit();
            }

            // get main screen trades list
            if(!isset($_GET['tid'])) {
                // Get trades count
                $TradeCounter = $DB -> prepare('SELECT COUNT(*) AS total FROM trades');
                $TradeCounter -> execute();
                $TradeCount = $TradeCounter -> fetch(PDO::FETCH_ASSOC);

                // Get trades
                $Limit = $TradesPerPage;
                $Offset = 0;
                if(isset($_GET['page']) && !empty($_GET['page']) && is_numeric($_GET['page'])) {
                    $Page = (int) $_GET['page'];
                    $Offset = ($Page - 1) * $TradesPerPage;
                }

                $TradeDigest = $DB -> prepare("SELECT trades.*, users.username AS username, users.external_id AS external_id FROM trades JOIN users ON trades.creator = users.login ORDER BY ID DESC LIMIT :limit OFFSET :offset");
                $TradeDigest -> bindParam(':limit', $Limit, PDO::PARAM_INT);
                $TradeDigest -> bindParam(':offset', $Offset, PDO::PARAM_INT);
                $TradeDigest -> execute();
            }
            
            // get sub screen offers list
            if(isset($_GET['tid']) && is_numeric($_GET['tid'])) {
                // Get trades count
                $TID = filter_input(INPUT_GET, 'tid', FILTER_SANITIZE_STRING);
                $OfferCounter = $DB -> prepare('SELECT COUNT(*) AS total FROM offers WHERE trade_id = :tid');
                $OfferCounter -> bindParam(':tid', $TID, PDO::PARAM_INT);
                $OfferCounter -> execute();
                $OfferCount = $OfferCounter -> fetch(PDO::FETCH_ASSOC);

                // Get trades
                $Limit = $OffersPerPage;
                $Offset = 0;
                if(isset($_GET['page']) && !empty($_GET['page']) && is_numeric($_GET['page'])) {
                    $Page = (int) $_GET['page'];
                    $Offset = ($Page - 1) * $TradesPerPage;
                }

                $OfferDigest = $DB -> prepare("SELECT offers.*, users.*, trades.creator AS tcreator, trades.state AS state FROM offers JOIN users ON offers.creator = users.login JOIN trades ON trades.ID = offers.trade_id WHERE offers.trade_id = :tid ORDER BY ID DESC LIMIT :limit OFFSET :offset");
                $OfferDigest -> bindParam(':tid', $TID, PDO::PARAM_INT);
                $OfferDigest -> bindParam(':limit', $Limit, PDO::PARAM_INT);
                $OfferDigest -> bindParam(':offset', $Offset, PDO::PARAM_INT);
                $OfferDigest -> execute();
            }

        } catch (PDOException $e) {
            echo "error".$e;
            exit();
            $_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
            //$_SESSION['error'] = $e;
            header("Location: /pages/home.php");
            exit();
        }
    }

    //generate CSRF token
    $CSRFToken = GenerateCSRF();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="login panel">
        <link rel="icon" href="/assets/favicon64.ico" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/assets/style_common.css">
        <link rel="stylesheet" href="/assets/style_editor.css">
        <link rel="stylesheet" href="/assets/style_shop.css">
        <meta http-equiv="Cache-Control" content="max-age=3600">
        <title>Serwis Barterowy</title>
        <script>
            function closeError() {
                var popup = document.getElementById('error-popup');
                popup.style.display = 'none';
            }
            function openEditor() {
                var blocker = document.getElementById('editor-blocker');
                var editor = document.getElementById('editor');
                var body = document.body;
                blocker.style.display = 'block';
                editor.style.display = 'block';
                body.classList.add('no-scroll');
            }
            function closeEditor() {
                var blocker = document.getElementById('editor-blocker');
                var editor = document.getElementById('editor');
                var body = document.body;
                blocker.style.display = 'none';
                editor.style.display = 'none';
                body.classList.remove('no-scroll');
            }
        </script>
    </head>
    <body>
        <nav class="menu-bar">
            <a href="/pages/forum.php"><div class="menu-item">Forum</div></a>
            <a href="/pages/chat.php"><div class="menu-item">Chat</div></a>
            <a href="/pages/settings.php"><div class="menu-item">Profil</div></a>
            <?php
                if($Elevated) {
                    echo '<a href="/pages/admin.php"><div class="menu-item">Aministracja</div></a>';
                }
                if(isset($_GET['tid'])) {
                    echo '<a href="/pages/shop.php" style="position: absolute; right: 9vw;"><div class="menu-item">Wróć</div></a>';
                } else {
                    echo '<a href="/pages/home.php" style="position: absolute; right: 9vw;"><div class="menu-item">Strona domowa</div></a>';
                }
            ?>
            <form action="shop.php" method="post" class="logout">
                <input type="hidden" name="logout" value="1">
                <input type="hidden" name="CSRF" value="<?php echo $CSRFToken;?>">
                <input type="submit" id="logout-button" value="Wyloguj się">
            </form>
        </nav>


        <?php
            // main trade list
            if (!isset($_GET['tid'])) {
                // display trades
                $Trades = $TradeDigest -> fetch(PDO::FETCH_ASSOC);
                
                for ($i = 0; $i < $TradesPerPage; $i++) {
                    if(empty($Trades['ID'])) { continue; }
                    echo '<a href="/pages/shop.php?tid='.$Trades['ID'].'" class="trade-link">'; // TRADE LINK
                    echo '<div class="trade-container"><table border><tr><td rowspan="3" class="trade-photo">';

                    // PHOTO
                    $GetPhotos = $DB -> prepare("SELECT mediaINtrades.trade_id AS trade_id, media.media_id AS media_id, media.extension AS extension FROM mediaINtrades LEFT JOIN media ON mediaINtrades.media_id = media.media_id HAVING mediaINtrades.trade_id = :tid");
                    $GetPhotos -> bindParam(':tid', $Trades['ID'], PDO::PARAM_INT);
                    $GetPhotos -> execute();
                    $MediaInfo = $GetPhotos -> fetch(PDO::FETCH_ASSOC);
                    
                    $MediaDIR = $_SERVER['DOCUMENT_ROOT'] . '/media/';
                    $Filename = $MediaInfo['media_id'] . '.' . $MediaInfo['extension'];
                    $MediaFile = $MediaDIR . $Filename;
                    if (!file_exists($Filename)) {
                        $Querry = $DB -> prepare("SELECT data FROM media WHERE media_id = :id");
                        $Querry -> bindParam(':id', $MediaInfo['media_id']);
                        $Querry -> execute();
                        $DownloadedFile = $Querry -> fetch(PDO::FETCH_ASSOC);
                        if ($DownloadedFile['data']) {
                            file_put_contents($MediaFile, $DownloadedFile['data']);
                        }
                    }
                    if(empty($MediaInfo['trade_id'])) {
                        $PhotoURL = "/assets/null.png";
                    } else {
                        $PhotoURL = "/media/" . $Filename;
                    }
                    echo '<img src="'.$PhotoURL.'" alt="404" />';

                     // TITLE
                    echo '</td><td class="trade-title">';
                    echo htmlspecialchars(base64_decode($Trades['title']), ENT_QUOTES, 'UTF-8');

                    // DESCRIPTION
                    echo '</td></tr><tr><td class="trade-description">';
                    echo '<pre>'.htmlspecialchars(base64_decode($Trades['body']), ENT_QUOTES, 'UTF-8').'</pre>';

                    // AUTHOR AND LINK
                    echo '</td></tr><tr><td class="trade-author">';
                    echo '<a href="/pages/profile.php?uid='.$Trades['external_id'].'"><span class="highlight">'.htmlspecialchars($Trades['username'], ENT_QUOTES, 'UTF-8').'</span></a>, '.htmlspecialchars($Trades['created_date'], ENT_QUOTES, 'UTF-8');
                    echo '</td></tr></table></div></a>';

                    $Trades = $TradeDigest -> fetch(PDO::FETCH_ASSOC);
                }

                // page listing - main
                echo '<div id="page-listing">';
                $PagesNum = ceil($TradeCount['total'] / $TradesPerPage);
                for($i = 1; $i <= $PagesNum; $i++) {
                    echo '<a href="/pages/shop.php?page='.$i.'" class="page-link"><div class="page-number">'.$i.'</div></a>';
                }
                echo '</div>';
 
                // new post button
                echo '<div id="new-trade-button" onclick="openEditor()">Nowy</div>';

                // editor - add
                echo '<div id="editor-blocker"><div id="editor"><form action="shop.php" method="post" enctype="multipart/form-data"><div id="editor-close" onclick="closeEditor()">x</div><table id="editor-table">';
                echo '<tr><td id="editor-title-container"><input type="text" name="title" id="editor-title" placeholder="Nagłówek"></td></tr>';
                echo '<tr><td><textarea id="editor-body" name="body" placeholder="Opis"></textarea></td></tr>';
                echo '<tr><td id="editor-files">Dodaj zdjęcie: <input type="file" name="photo"></td></tr>';
                echo '<tr><td id="editor-save-container"><input type="hidden" name="CSRF" value="'. $CSRFToken . '">';
                echo '<input type="hidden" name="edit" value="0"><input type="submit" id="editor-save" value="Zapisz"></td></tr></table></form></div></div>';
            }



            // inside trade offer view
            if (isset($_GET['tid'])) {
                $TID = filter_input(INPUT_GET, 'tid', FILTER_SANITIZE_STRING);
                $GetTrade = $DB -> prepare("SELECT trades.*, users.* FROM trades JOIN users ON trades.creator = users.login WHERE ID = :tid");
                $GetTrade -> bindParam(':tid', $TID);
                $GetTrade -> execute();
                $Trade = $GetTrade -> fetch(PDO::FETCH_ASSOC);
                if(empty($Trade['ID'])) {
                    $_SESSION['error'] = "Nie znaleziono oferty wymiany!";
                    header("Location: /pages/shop.php");
                    exit();
                }

                // PHOTO
                $GetPhotos = $DB -> prepare("SELECT mediaINtrades.trade_id AS trade_id, media.media_id AS media_id, media.extension AS extension FROM mediaINtrades LEFT JOIN media ON mediaINtrades.media_id = media.media_id HAVING mediaINtrades.trade_id = :tid");
                $GetPhotos -> bindParam(':tid', $TID);
                $GetPhotos -> execute();
                $MediaInfo = $GetPhotos -> fetch(PDO::FETCH_ASSOC);
                
                $MediaDIR = $_SERVER['DOCUMENT_ROOT'] . '/media/';
                $Filename = $MediaInfo['media_id'] . '.' . $MediaInfo['extension'];
                $MediaFile = $MediaDIR . $Filename;
                if (!file_exists($Filename)) {
                    $Querry = $DB -> prepare("SELECT data FROM media WHERE media_id = :id");
                    $Querry -> bindParam(':id', $MediaInfo['media_id']);
                    $Querry -> execute();
                    $DownloadedFile = $Querry -> fetch(PDO::FETCH_ASSOC);
                    if ($DownloadedFile['data']) {
                        file_put_contents($MediaFile, $DownloadedFile['data']);
                    }
                }
                if(empty($MediaInfo['trade_id']) || $Filename == ".") {
                    $PhotoURL = "/assets/null.png";
                } else {
                    $PhotoURL = "/media/" . $Filename;
                }
                echo '<div id="trade-full-container"><table><tr><td rowspan="3" id="trade-full-photo">';
                echo '<img src="'.$PhotoURL.'" alt="404" />';

                // TITLE
                echo '</td><td id="trade-full-title">';
                echo htmlspecialchars(base64_decode($Trade['title']), ENT_QUOTES, 'UTF-8');

                // BODY
                echo '</td></tr><tr><td id="trade-full-description">';
                switch ($Trade['state']) {
                    case 'OPEN':
                        $State_text = 'Otwarty';
                        break;
                    case 'HALF':
                        $State_text = 'Wstępna zgoda';
                        break;
                    case 'FULL':
                        $State_text = 'Wymiana zakończona';
                        break;
                }
                echo '<pre>'.htmlspecialchars(base64_decode($Trade['body']), ENT_QUOTES, 'UTF-8').'</pre><br><br>Stan: '.htmlspecialchars($State_text , ENT_QUOTES, 'UTF-8');

                // AUTHOR
                echo '</td></tr><tr><td id="trade-full-author">';
                echo '<div><a href="/pages/profile.php?uid='.$Trade['external_id'].'"><span class="highlight">'.htmlspecialchars($Trade['username'], ENT_QUOTES, 'UTF-8').'</span></a>, '.htmlspecialchars($Trade['created_date'], ENT_QUOTES, 'UTF-8').'</div>';
                
                if ($Trade['state'] == 'HALF') {
                    $UserCompare = $DB -> prepare("SELECT creator, ID FROM offers WHERE ID IN (SELECT offer_id FROM trades WHERE ID = :tid)");
                    $UserCompare -> bindParam(':tid', $TID);
                    $UserCompare -> execute();
                    $AgreedUser = $UserCompare -> fetch(PDO::FETCH_ASSOC);

                    if($AgreedUser['creator'] == $CurrentUser['login'] || $CurrentUser['level'] >= 1000) {
                        echo '<br><span class="action-accept"><a href="/pages/shop.php?oid='.$AgreedUser['ID'].'&CSRF='.$CSRFToken.'&offeraccept=1">(Akceptuj)</a></span>';
                    }
                }
                
                echo '</td></tr></table></div>';



                // offers listing
                for ($i = 0; $i < $OffersPerPage; $i++) {
                    $Offer = $OfferDigest -> fetch(PDO::FETCH_ASSOC);
                    if(empty($Offer['ID'])) { continue; }

                    if($Trade['state'] == 'DONE' && $Trade['offer_id'] == $Offer['ID']) {
                        echo '<div class="offer-container accepted"><table><tr><td rowspan="3" class="offer-photo">';
                    } 
                    else if ($Trade['state'] == 'HALF' && $Trade['offer_id'] == $Offer['ID']) {
                        echo '<div class="offer-container in-progress"><table><tr><td rowspan="3" class="offer-photo">';
                    } else {
                        echo '<div class="offer-container"><table><tr><td rowspan="3" class="offer-photo">';
                    }

                    // PHOTO
                    $GetPhotos = $DB -> prepare("SELECT mediaINoffers.offer_id AS offer_id, media.media_id AS media_id, media.extension AS extension FROM mediaINoffers LEFT JOIN media ON mediaINoffers.media_id = media.media_id HAVING mediaINoffers.offer_id = :oid");
                    $GetPhotos -> bindParam(':oid', $Offer['ID']);
                    $GetPhotos -> execute();
                    $MediaInfo = $GetPhotos -> fetch(PDO::FETCH_ASSOC);
                    
                    $MediaDIR = $_SERVER['DOCUMENT_ROOT'] . '/media/';
                    $Filename = $MediaInfo['media_id'] . '.' . $MediaInfo['extension'];
                    $MediaFile = $MediaDIR . $Filename;
                    if (!file_exists($Filename)) {
                        $Querry = $DB -> prepare("SELECT data FROM media WHERE media_id = :id");
                        $Querry -> bindParam(':id', $MediaInfo['media_id']);
                        $Querry -> execute();
                        $DownloadedFile = $Querry -> fetch(PDO::FETCH_ASSOC);
                        if ($DownloadedFile['data']) {
                            file_put_contents($MediaFile, $DownloadedFile['data']);
                        }
                    }
                    if(empty($MediaInfo['offer_id']) || $Filename == ".") {
                        $PhotoURL = "/assets/null.png";
                    } else {
                        $PhotoURL = "/media/" . $Filename;
                    }
                    echo '<img src="'.$PhotoURL.'" alt="404" />';

                    // BODY
                    echo '</td><td class="offer-body">';
                    echo '<pre>'.htmlspecialchars(base64_decode($Offer['body']), ENT_QUOTES, 'UTF-8').'</pre>';

                    // AUTHOR
                    echo '</td></tr><tr><td class="offer-author"><div>';
                    echo '<a href="/pages/profile.php?uid='.$Offer['external_id'].'"><span class="highlight">'.htmlspecialchars($Offer['username'], ENT_QUOTES, 'UTF-8').'</span></a>, '.htmlspecialchars($Offer['created_date'], ENT_QUOTES, 'UTF-8'); // AUTHOR
                    echo '</div><br><div class="offer-action">';
                    
                    // ACTION LINKS
                    if($CurrentUser['login'] == $Offer['creator'] || ($Offer['level'] < $CurrentUser['level'] && $CurrentUser['level'] >= 100) || $CurrentUser['level'] >= 1000) {
                        echo '<span class="action-delete"><a href="/pages/shop.php?oid='.$Offer['ID'].'&CSRF='.$CSRFToken.'&offerdelete=1">(Usuń)</a></span>';
                    }

                    if(($CurrentUser['login'] == $Offer['tcreator'] || $CurrentUser['level'] >= 1000) && $Offer['state'] == 'OPEN') {
                        echo '<span class="action-accept"><a href="/pages/shop.php?oid='.$Offer['ID'].'&CSRF='.$CSRFToken.'&offeraccept=1">(Akceptuj)</a></span>';
                    }
                    
                    echo '</div></td></tr></table></div>';
                }


                // new offer form
                echo '<div id="new-offer-container"><form action="shop.php?tid='.$Trade['ID'].'" method="post" enctype="multipart/form-data"><table><tr><td id="new-offer-description-body">';
                echo '<textarea name="body" placeholder="Opis" id="new-offer-body"></textarea>';
                echo '<br>';
                echo 'Dodaj zdjęcie: <input type="file" name="photo">';
                echo '</td><td id="new-offer-captcha">';
                echo '<img src="?captcha=" alt="???" id="captcha_img" onclick="document.getElementById(\'captcha_img\').src=\'?captcha=\'+Math.random();" />';
                echo '<br>';
                echo '<input type="text" name="captcha" placeholder="Rozwiązanie captcha" id="offer-new-captcha-box">';
                echo '<input type="hidden" name="addoffer" value="1">';
                echo '<input type="hidden" name="CSRF" value="' . $CSRFToken . '">';
                echo '<input type="submit" value="Wyślij" id="new-offer-submit">';
                echo '</td></tr></table></form></div>';


                // page listing - sub
                $OfferCounter = $DB -> prepare("SELECT COUNT(*) AS total FROM offers WHERE trade_id = :tid");
                $OfferCounter -> bindParam(':tid', $TID);
                $OfferCounter -> execute();
                $OfferCount = $OfferCounter -> fetch(PDO::FETCH_ASSOC);

                echo '<div id="page-listing">';
                $PagesNum = ceil($OfferCount['total'] / $OffersPerPage);
                for($i = 1; $i <= $PagesNum; $i++) {
                    echo '<a href="/pages/shop.php?tid='.$Trade['ID'].'&page='.$i.'" class="page-link"><div class="page-number">'.$i.'</div></a>';
                }
                echo '</div>';
 
                // edit button
                if($Trade['creator'] == $CurrentUser['login'] || ($Trade['level'] < $CurrentUser['level'] && $CurrentUser['level'] >= 100)) {
                    echo '<div id="new-trade-button" onclick="openEditor()">Edytuj</div>';
                }
                
                // editor - edit
                echo '<div id="editor-blocker"><div id="editor"><form action="shop.php?tid='.$Trade['ID'].'" method="post" enctype="multipart/form-data"><div id="editor-close" onclick="closeEditor()">x</div><table id="editor-table">';
                echo '<tr><td id="editor-title-container"><input type="text" name="title" id="editor-title" placeholder="Nagłówek" value="'.htmlspecialchars(base64_decode($Trade['title']), ENT_QUOTES, 'UTF-8').'"></td></tr>';
                echo '<tr><td><textarea id="editor-body" name="body" placeholder="Opis">'.htmlspecialchars(base64_decode($Trade['body']), ENT_QUOTES, 'UTF-8').'</textarea></td></tr>';
                echo '<tr><td id="editor-files">Dodaj zdjęcie: <input type="file" name="photo"></td></tr>';
                echo '<tr><td><input type="checkbox" name="delete" value="1">Usunąć?</td></tr>';
                echo '<tr><td id="editor-save-container"><input type="hidden" name="CSRF" value="'. $CSRFToken . '">';
                echo '<input type="hidden" name="edit" value="1"><input type="submit" id="editor-save" value="Zapisz"></td></tr></table></form></div></div>';
            }

            $DB = null;
            // error message
            if(!empty($_SESSION['error'])) {
                echo "<div id=\"error-popup\">";
                echo "<button class=\"error-close\" onclick=\"closeError()\">x</button>";
                echo "<p id=\"error-message\">" . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . "</p>";
                echo "</div>";
                unset($_SESSION['error']);
            }
        ?>
    </body>
</html>