<?php
    // if not logged in - redirect to login
    session_start();
    if (!isset($_SESSION['login'])) {
        header("Location: /pages/login.php");
        exit();
    }

    // import CSRF utility
    require("../functions/csrf.php");

    // import filter
    require("../functions/filter.php");

    // logout
    require("../functions/logout.php");
    if(isset($_POST['logout'])) {
        // CSRF check
        if(!CheckCSRF()){
            header("Location: /pages/home.php");
            exit();
        }

        // logout
        Logout();
        exit();
    }

    // database lookups
    if(!(isset($_SESSION['error']) && $_SESSION['error'] === "Wystąpił błąd serwera, spróbój ponownie później.")){ 
        try {
            require("../config/db.php");
            $DB = new PDO("mysql:host=$DBhost;dbname=$DBname", $DBuser, $DBpass);
            $DB -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $Querry = $DB -> prepare("SELECT level, permaban, ban, active, CASE WHEN ban IS NULL THEN 0 ELSE 1 END AS isbanned FROM users WHERE login = :login");
            $Querry -> bindParam(':login', $_SESSION['login']);
            $Querry -> execute();
            $Record = $Querry -> fetch(PDO::FETCH_ASSOC);

            // is permabanned?
            if($Record['permaban'] != 0) {
                Logout("Konto zostało pernamentnie zbanowane!");
                $DB = null;
                exit();
            }

            // is regular ban or deactivated?
            if($Record['active'] != 1) {
                if(!empty($Record['ban'])) {
                    Logout("Konto jest zbanowane do ".$Record['ban'].".");
                } else {
                    Logout("Konto zostało deaktywowane!");
                }
                $DB = null;
                exit();
            }

            // should the admin panel option be shown?
            if($Record['level'] >= 100) {$Elevated = true;} else {$Elevated = false;}
            $Userlevel = $Record['level'];

            // get news
            if(!isset($_GET['id'])){
                // get 10 newest news
                $Querry = $DB -> prepare("SELECT news.*, users.username AS creator_username, edited_user.username AS editor_username, users.external_id AS creator_id, edited_user.external_id AS editor_id FROM news JOIN users ON news.creator = users.login LEFT JOIN users AS edited_user ON news.edited_by = edited_user.login ORDER BY created_date DESC LIMIT 10");
                $Querry -> execute();
                $News = $Querry -> fetch(PDO::FETCH_ASSOC);
            } else {
                // get 1 article
                $ID = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_STRING);
                $Querry = $DB -> prepare("SELECT news.*, users.username AS creator_username, edited_user.username AS editor_username, users.external_id AS creator_id, edited_user.external_id AS editor_id FROM news JOIN users ON news.creator = users.login LEFT JOIN users AS edited_user ON news.edited_by = edited_user.login WHERE news.ID = :id");
                $Querry -> bindParam(':id', $ID);
                $Querry -> execute();
                $News = $Querry -> fetch(PDO::FETCH_ASSOC);

                // 404
                if(empty($News)) {
                    $_SESSION['error'] = "Nie znaleziono artykułu!";
                    header("Location: /pages/home.php");
                    exit();
                }
            }

            // add / update news
            if(isset($_POST['edit']) && $Elevated) {
                // CSRF check
                if(!CheckCSRF()){
                    header("Location: /pages/home.php");
                    exit();
                }
        
                // add
                if($_POST['edit'] == 0) {
                    if(!$Elevated) {
                        $_SESSION['error'] = "Nie masz uprawnień do tworzenia artykułów.";
                        header("Location: /pages/home.php");
                        exit();
                    }
                    $Title = base64_encode(Filter(filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING)));
                    $Body = base64_encode(Filter(filter_input(INPUT_POST, 'body', FILTER_SANITIZE_STRING)));
                    $Querry = $DB -> prepare("INSERT INTO news (creator, created_date, title, body, edit_level) VALUES (:login, NOW(), :title, :body, :level)");
                    $Querry -> bindParam(':login', $_SESSION['login']);
                    $Querry -> bindParam(':title', $Title);
                    $Querry -> bindParam(':body', $Body);
                    $Querry -> bindParam(':level', $Userlevel);
                    $Querry -> execute();
                    //$UpdateCheck = $Querry -> fetch(PDO::FETCH_ASSOC);
                    //$_SESSION['error'] = var_dump($UpdateCheck);
                    header("Location: /pages/home.php");
                    exit();
                }

                // edit
                if($_POST['edit'] == 1) {
                    // lvl
                    if($Userlevel < $News['edit_level'] || !$Elevated) {
                        $_SESSION['error'] = "Nie masz uprawnień do edycji tego artykułu.";
                        header("Location: /pages/home.php");
                        exit();
                    }
                    $EditID = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_STRING);

                    // delete
                    if(isset($_POST['delete']) && $_POST['delete'] == 1) {
                        $Querry = $DB -> prepare("DELETE FROM news WHERE ID = :id");
                        $Querry -> bindParam(':id', $EditID);
                        $Querry -> execute();
                        //$UpdateCheck = $Querry -> fetch(PDO::FETCH_ASSOC);
                        //$_SESSION['error'] = var_dump($UpdateCheck);
                        header("Location: /pages/home.php");
                        exit();
                    }
                    
                    $Title = base64_encode(Filter(filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING)));
                    $Body = base64_encode(Filter(filter_input(INPUT_POST, 'body', FILTER_SANITIZE_STRING)));
                    $Login = $_SESSION['login'];
                    $Querry = $DB -> prepare("UPDATE news SET title = :title, body = :body, edit_level = :level, edit_date = NOW(), edited_by = :login WHERE ID = :id");
                    $Querry -> bindParam(':title', $Title);
                    $Querry -> bindParam(':body', $Body);
                    $Querry -> bindParam(':level', $Userlevel);
                    $Querry -> bindParam(':login', $_SESSION['login']);
                    $Querry -> bindParam(':id', $EditID);
                    $Querry -> execute();
                    //$UpdateCheck = $Querry -> fetch(PDO::FETCH_ASSOC);
                    //$_SESSION['error'] = var_dump($UpdateCheck);
                    header("Location: /pages/home.php");
                    exit();
                }
            }

            // Get UTC time
            $TimeLookup = $DB -> prepare("SELECT UTC_TIMESTAMP() AS utcdatetime");
            $TimeLookup -> execute();
            $UTC = $TimeLookup -> fetch(PDO::FETCH_ASSOC);

            // Get weather 52.341294726945165, 
            $WeatherAPI = "https://api.open-meteo.com/v1/forecast?latitude=52.341294726945165&longitude=17.57053699080422&hourly=temperature_2m,weather_code,wind_speed_10m";
            $WeatherAPIResponse = file_get_contents($WeatherAPI);
            $WeatherData = json_decode($WeatherAPIResponse, true);

        } catch (PDOException $e) {
            $_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
            //$_SESSION['error'] = $e;
            header("Location: /pages/home.php");
            exit();
        }
    }
    $DB = null;

    function findValuesInRange(array $Array, int $Start, int $End): array {
        $SubArray = array_slice($Array, $Start, $End - $Start + 1);
    
        $Min = min($SubArray);
        $Avg = round(array_sum($SubArray) / count($SubArray), 1);
        $Max = max($SubArray);
    
        // Return an associative array with min and max values
        return [
            'min' => $Min,
            'avg' => $Avg,
            'max' => $Max
        ];
    }
    function weatherCodeLookup(string $Code) {
        $Map = [
             '0' => 'Bezchmurnie',
             '1' => 'Lekkie zachmurzenie',
             '2' => 'Częściowe zachmurzenie',
             '3' => 'Zachmurzenie',
            '45' => 'Mgła',
            '48' => 'Mgła ze skropleniem',
            '51' => 'Lekka mżawka',
            '53' => 'Mżawka',
            '55' => 'Gęsta mżawka',
            '56' => 'Lekka marznąca mżawka',
            '57' => 'Gęsta marznąca mżawka',
            '61' => 'Lekki deszcz',
            '63' => 'Deszcz',
            '65' => 'Gęsty deszcz',
            '66' => 'Lekki marznący deszcz',
            '67' => 'Gęsty marznący deszcz',
            '71' => 'Lekkie opady śniegu',
            '73' => 'Opady śniegu',
            '75' => 'Geste opady śniegu',
            '77' => 'Śnieg ziarnisty',
            '80' => 'Deszcz',
            '81' => 'Deszcz',
            '82' => 'Ulewa',
            '85' => 'Śnieżyca',
            '86' => 'Śnieżyca',
            '95' => 'Burza',
            '96' => 'Burza z gradem',
            '99' => 'Burza z ciężkim gradem'
        ];
        if (array_key_exists($Code, $Map)) {
            return $Map[$Code];
        } else {
            return null;
        }
        
    }

    //generate CSRF token
    $CSRFToken = GenerateCSRF();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="login panel">
        <link rel="icon" href="/assets/favicon64.ico" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/assets/style_common.css">
        <link rel="stylesheet" href="/assets/style_editor.css">
        <link rel="stylesheet" href="/assets/style_home.css">
        <meta http-equiv="Cache-Control" content="max-age=3600">
        <title>Strona domowa</title>
        <script>
            function closeError() {
                var popup = document.getElementById('error-popup');
                popup.style.display = 'none';
            }
            function openEditor() {
                var blocker = document.getElementById('editor-blocker');
                var editor = document.getElementById('editor');
                var body = document.body;
                blocker.style.display = 'block';
                editor.style.display = 'block';
                body.classList.add('no-scroll');
            }
            function closeEditor() {
                var blocker = document.getElementById('editor-blocker');
                var editor = document.getElementById('editor');
                var body = document.body;
                blocker.style.display = 'none';
                editor.style.display = 'none';
                body.classList.remove('no-scroll');
            }
            let UTCDateTime = new Date('<?php echo $UTC['utcdatetime']; ?>');
            function Tick() {
                UTCDateTime.setSeconds(UTCDateTime.getSeconds() + 1);
                let UTC = UTCDateTime.getUTCHours().toString().padStart(2, '0');
                let UTCP2 = (Math.abs(UTCDateTime.getUTCHours()+2)%24).toString().padStart(2, '0');
                let UTCP3 = (Math.abs(UTCDateTime.getUTCHours()+3)%24).toString().padStart(2, '0');
                let UTCM4 = (Math.abs(UTCDateTime.getUTCHours()-4)%24).toString().padStart(2, '0');
                let UTCP9 = (Math.abs(UTCDateTime.getUTCHours()+9)%24).toString().padStart(2, '0');
                let Minutes = UTCDateTime.getUTCMinutes().toString().padStart(2, '0');
                let Seconds = UTCDateTime.getUTCSeconds().toString().padStart(2, '0');
                document.getElementById('info-clock').innerHTML = `UTC: ${UTC}:${Minutes}:${Seconds}<br>Warsaw: ${UTCP2}:${Minutes}:${Seconds}<br>Moscow: ${UTCP3}:${Minutes}:${Seconds}<br>New York: ${UTCM4}:${Minutes}:${Seconds}<br>Tokyo: ${UTCP9}:${Minutes}:${Seconds}`;
            }
            function init() {
                Tick();
                setInterval(Tick, 1000);
            }
        </script>
    </head>
    <body onload="init()">
        <nav class="menu-bar">
            <a href="/pages/forum.php"><div class="menu-item">Forum</div></a>
            <a href="/pages/chat.php"><div class="menu-item">Chat</div></a>
            <a href="/pages/shop.php"><div class="menu-item">Sklep</div></a>
            <a href="/pages/settings.php"><div class="menu-item">Profil</div></a>
            <?php
                if($Elevated) {
                    echo '<a href="/pages/admin.php"><div class="menu-item">Aministracja</div></a>';
                }
                if(isset($_GET['id'])){
                    echo '<a href="/pages/home.php" style="position: absolute; right: 9vw;"><div class="menu-item">Wróć</div></a>';
                }
            ?>
            <form action="home.php" method="post" class="logout">
                <input type="hidden" name="logout" value="1">
                <input type="hidden" name="CSRF" value="<?php echo $CSRFToken;?>">
                <input type="submit" id="logout-button" value="Wyloguj się">
            </form>
        </nav>

        <div id="info-window">
            <table border>
                <tr>
                    <td rowspan="2" id="info-clock">
                        CLOCK
                    </td>
                    <?php
                        try {
                            for ($i = 0; $i < 7; $i++) {
                                echo '<td class="info-weather-label">';
                                echo substr($WeatherData['hourly']['time'][$i * 24], 0, -6);
                                echo '</td>';
                            }
                        } catch (throwable $e) {
                            // do nothing and let the rest of the page load
                        }
                    ?>
                </tr>
                <tr>
                    <?php
                        try {
                            for ($i = 0; $i < 7; $i++) {
                                $Temps = findValuesInRange($WeatherData['hourly']['temperature_2m'], $i * 24, $i * 24 + 23);
                                $Winds = findValuesInRange($WeatherData['hourly']['wind_speed_10m'], $i * 24, $i * 24 + 23);
                                $Status = findValuesInRange($WeatherData['hourly']['weather_code'], $i * 24, $i * 24 + 23);
    
                                echo '<td class="info-weather">';
                                echo 'Temp max: ' . $Temps['max'] . '&deg;C<br>';
                                echo 'Temp min: ' . $Temps['min'] . '&deg;C<br>';
                                echo 'Wiatr: ' . $Winds['avg'] . 'km/h<br><br>';
                                echo weatherCodeLookup($Status['max']);
                            }
                        } catch (throwable $e) {
                            // do nothing and let the rest of the page load
                        }
                    ?>
                </tr>
            </table>
        </div>

        <?php
            if(isset($_GET['id'])) {
                // single article
                echo '<div class=story><table><tr><td class="inside-title">';
                echo htmlspecialchars(base64_decode($News['title']), ENT_QUOTES, 'UTF-8');
                echo '</td></tr><tr><td class="inside-story"><pre>';
                echo htmlspecialchars(base64_decode($News['body']), ENT_QUOTES, 'UTF-8');
                echo '</pre></td></tr><tr><td class="inside-credits"><div class="inside-author">';
                echo 'Autor: <a href=/pages/profile.php?uid=' . $News['creator_id'] . ' class="news-userlink">' . htmlspecialchars($News['creator_username'], ENT_QUOTES, 'UTF-8') . '</a></div>';
                if(isset($News['edited_by'])) {
                    $Editor = $News['editor_username'];
                    $Edited_on = 'Dnia: ' . $News['edit_date'];
                    echo '<div class="inside-edit">Edycja przez: <a href=/pages/profile.php?uid=' . $News['editor_id'] . ' class="news-userlink">' . htmlspecialchars($Editor, ENT_QUOTES, 'UTF-8') . '</a>, ' . htmlspecialchars($Edited_on, ENT_QUOTES, 'UTF-8') . '</div>';
                }
                echo '</td></tr></table></div>';
                

            } else {
                // article list
                while (!empty($News)) {
                    if(!empty($News['edited_by'])) {
                        $Editor = "Edycja przez: " . '<a href=/pages/profile.php?uid=' . $News['editor_id'] . ' class="news-userlink">' . htmlspecialchars($News['editor_username'], ENT_QUOTES, 'UTF-8') . '</a>';
                        $Edited_on = "Dnia: " . htmlspecialchars($News['edit_date'], ENT_QUOTES, 'UTF-8');
                    } else {
                        $Editor = "";
                        $Edited_on = "";
                    }
                    $Created = explode(' ', $News['created_date']);
                    echo '<a href="/pages/home.php?id=' . $News['ID'] .'" class="story-link"><div class="story-widget"><table><tr>';
                    echo '<td class="story-title">' . htmlspecialchars(base64_decode($News['title']), ENT_QUOTES, 'UTF-8') . '</td>';
                    echo '<td class="story-date">' . htmlspecialchars($Created[0], ENT_QUOTES, 'UTF-8'). "<br>" . htmlspecialchars($Created[1], ENT_QUOTES, 'UTF-8') . '</td></tr><tr>';
                    echo '<td class="story-user">Twórca: <a href=/pages/profile.php?uid=' . $News['creator_id'] . ' class="news-userlink">' . htmlspecialchars($News['creator_username'], ENT_QUOTES, 'UTF-8') . '</a></td>';
                    echo '<td class="story-edited">' . $Editor . "<br>" . $Edited_on . '</td>';
                    echo '</tr></table></div></a>';
                    $News = $Querry -> fetch(PDO::FETCH_ASSOC);
                }
            }

            // editor
            if($Elevated) {
                // main view
                if(!isset($_GET['id'])) {
                    // add button
                    echo '<div class="news-add-button" onclick="openEditor()">Dodaj</div>';

                    // editor
                    echo '<div id="editor-blocker"><div id="editor"><form action="home.php" method="post"><div id="editor-close" onclick="closeEditor()">x</div>';
                    echo '<table id="editor-table"><tr><td id="editor-title-container"><input type="text" name="title" id="editor-title" placeholder="Tytuł">';
                    echo '</td></tr><tr><td><textarea id="editor-body" name="body" placeholder="Wpis"></textarea></td></tr><tr>';
                    echo '<td id="editor-save-container"><input type="hidden" name="CSRF" value="'. $CSRFToken . '">';
                    echo '<input type="hidden" name="edit" value="0"><input type="submit" id="editor-save" value="Zapisz"></td></tr></table></form></div></div>';
                } else {
                    // inside view
                    echo '<div class="news-add-button" onclick="openEditor()">Edytuj</div>';

                    // editor
                    echo '<div id="editor-blocker"><div id="editor"><form action="home.php" method="post"><div id="editor-close" onclick="closeEditor()">x</div><table id="editor-table"><tr><td id="editor-title-container">';
                    echo '<input type="text" name="title" id="editor-title" placeholder="Tytuł" value="'.htmlspecialchars(base64_decode($News['title']), ENT_QUOTES, 'UTF-8').'">';
                    echo '</td></tr><tr><td>';
                    echo '<textarea id="editor-body" name="body" placeholder="Wpis">'.htmlspecialchars(base64_decode($News['body']), ENT_QUOTES, 'UTF-8').'</textarea>';
                    echo '</td></tr>';
                    echo '<tr><td><input type="checkbox" name="delete" value="1">Usunąć?</td></tr>';
                    echo '<tr><td id="editor-save-container">';
                    echo '<input type="hidden" name="CSRF" value="'. $CSRFToken . '">';
                    echo '<input type="hidden" name="id" value="'. $News['ID'] . '">';
                    echo '<input type="hidden" name="edit" value="1"><input type="submit" id="editor-save" value="Zapisz">';
                    echo '</td></tr></table></form></div></div>';
                }
            }
            
            // error message
            if(!empty($_SESSION['error'])) {
                echo "<div id=\"error-popup\">";
                echo "<button class=\"error-close\" onclick=\"closeError()\">x</button>";
                echo "<p id=\"error-message\">" . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . "</p>";
                echo "</div>";
                unset($_SESSION['error']);
            }
        ?>
    </body>
</html>