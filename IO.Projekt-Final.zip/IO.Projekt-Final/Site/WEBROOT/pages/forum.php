<?php
    // if not logged in - redirect to login
    session_start();
    if (!isset($_SESSION['login'])) {
        header("Location: /pages/login.php");
        exit();
    }

    // generate captcha on demand
    if(isset($_GET['captcha'])) {
        require("../functions/captcha.php");
        GenerateCaptchaImage();
        exit();
    }

    // import CSRF utility
    require("../functions/csrf.php");

    // import filter
    require("../functions/filter.php");

    // import config
    require("../config/forum.php");

    // logout
    require("../functions/logout.php");
    if(isset($_POST['logout'])) {
        // CSRF check
        if(!CheckCSRF()){
            header("Location: /pages/home.php");
            exit();
        }

        // logout
        Logout();
        exit();
    }

    // database operations
    if(!(isset($_SESSION['error']) && $_SESSION['error'] === "Wystąpił błąd serwera, spróbój ponownie później.")){
        try {
            require("../config/db.php");
            $DB = new PDO("mysql:host=$DBhost;dbname=$DBname", $DBuser, $DBpass);
            $DB -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $Querry = $DB -> prepare("SELECT level, permaban, ban, active, CASE WHEN ban IS NULL THEN 0 ELSE 1 END AS isbanned, extension FROM users LEFT JOIN media ON profile_pic = media_id WHERE login = :login");
            $Querry -> bindParam(':login', $_SESSION['login']);
            $Querry -> execute();
            $Record = $Querry -> fetch(PDO::FETCH_ASSOC);

            // is permabanned?
            if($Record['permaban'] != 0) {
                Logout("Konto zostało pernamentnie zbanowane!");
                $DB = null;
                exit();
            }

            // is regular ban or deactivated?
            if($Record['active'] != 1) {
                if(!empty($Record['ban'])) {
                    Logout("Konto jest zbanowane do ".$Record['ban'].".");
                } else {
                    Logout("Konto zostało deaktywowane!");
                }
                $DB = null;
                exit();
            }

            // should the admin panel option be shown?
            if($Record['level'] >= 100) {$Elevated = true;} else {$Elevated = false;}
            $Userlevel = $Record['level'];


            
            // if post id is not set - get and display post list
            if(!isset($_GET['pid'])) {
                $Limit = $PostsPerPage;
                $Offset = 0;
                if(isset($_GET['page']) && !empty($_GET['page']) && is_numeric($_GET['page'])) {
                    $Page = (int) $_GET['page'];
                    $Offset = ($Page - 1) * $PostsPerPage;
                }

                // Total post number for how many pages are needed
                $Querry = $DB -> prepare("SELECT COUNT(*) AS total FROM posts");
                $Querry -> execute();
                $PostsTotal = $Querry -> fetch(PDO::FETCH_ASSOC);

                // Retrieve posts
                $PostsDigest = $DB -> prepare("SELECT posts.*, users.username AS creator_username, users.external_id AS creator_id, edited_user.username AS editor_username, edited_user.external_id AS editor_id FROM posts JOIN users ON posts.creator = users.login LEFT JOIN users AS edited_user ON posts.edited_by = edited_user.login ORDER BY posts.ID DESC LIMIT :limit OFFSET :offset");
                $PostsDigest -> bindParam(':limit', $Limit, PDO::PARAM_INT);
                $PostsDigest -> bindParam(':offset', $Offset, PDO::PARAM_INT);
                $PostsDigest -> execute();
            }

            // retrieve single post with paged comments
            if(isset($_GET['pid'])) {
                $Limit = $CommentsPerPage;
                $Offset = 0;
                if(isset($_GET['page']) && !empty($_GET['page']) && is_numeric($_GET['page'])) {
                    $Page = (int) $_GET['page'];
                    $Offset = ($Page - 1) * $CommentsPerPage;
                }
                
                // Get post
                $PID = filter_input(INPUT_GET, 'pid', FILTER_SANITIZE_STRING);
                $Querry = $DB -> prepare("SELECT posts.*, users.username AS creator_username, users.external_id AS creator_id, edited_user.username AS editor_username, edited_user.external_id AS editor_id FROM posts JOIN users ON posts.creator = users.login LEFT JOIN users AS edited_user ON posts.edited_by = edited_user.login WHERE ID = :pid");
                $Querry -> bindParam(':pid', $PID);
                $Querry -> execute();
                $Post = $Querry -> fetch(PDO::FETCH_ASSOC);

                // Get media
                $Querry = $DB -> prepare("SELECT media.media_id, media.extension FROM media INNER JOIN mediaINposts ON media.media_id = mediaINposts.media_id WHERE mediaINposts.post_id = :pid");
                $Querry -> bindParam(':pid', $PID);
                $Querry -> execute();
                $MediaRecord = $Querry -> fetch(PDO::FETCH_ASSOC);

                $MediaList = array();
                while(!empty($MediaRecord['media_id'])) {
                    array_push($MediaList, [$MediaRecord['media_id'], $MediaRecord['extension']]);
                    $MediaRecord = $Querry -> fetch(PDO::FETCH_ASSOC);
                }

                // If media is present
                $MediaListLen = count($MediaList);
                if($MediaListLen != 0) {
                    // Download all files in post from db to server in not present and save paths to $MediaList to use in links
                    $MediaDIR = $_SERVER['DOCUMENT_ROOT'] . '/media/';
                    for($i = 0; $i < $MediaListLen; $i++) {
                        $Filename = $MediaList[$i][0] . '.' . $MediaList[$i][1];
                        $MediaFile = $MediaDIR . $Filename;
                        if (!file_exists($Filename)) {
                            $Querry = $DB -> prepare("SELECT data FROM media WHERE media_id = :id");
                            $Querry -> bindParam(':id', $MediaList[$i][0]);
                            $Querry -> execute();
                            $DownloadedFile = $Querry -> fetch(PDO::FETCH_ASSOC);
                            if ($DownloadedFile['data']) {
                                file_put_contents($MediaFile, $DownloadedFile['data']);
                            }
                        }
                    }
                }

                // Get total comments
                $Querry = $DB -> prepare("SELECT COUNT(*) AS total FROM comments WHERE post_id = :pid");
                $Querry -> bindParam(':pid', $PID);
                $Querry -> execute();
                $CommentsTotal = $Querry -> fetch(PDO::FETCH_ASSOC);

                // Get comments
                $CommentDigest = $DB -> prepare("SELECT comments.*, users.username AS creator_username, users.level AS level, users.external_id AS creator_id FROM comments JOIN users ON comments.creator = users.login HAVING comments.post_id = :pid ORDER BY comments.ID DESC LIMIT :limit OFFSET :offset");
                $CommentDigest -> bindParam(':pid', $PID);
                $CommentDigest -> bindParam(':limit', $Limit, PDO::PARAM_INT);
                $CommentDigest -> bindParam(':offset', $Offset, PDO::PARAM_INT);
                $CommentDigest -> execute();
            }

            // add comment logic
            if(isset($_POST['addcomment']) && $_POST['addcomment'] == 1) {
                $PID = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_STRING);

                // CSRF check
                if(!CheckCSRF()){
                    header("Location: /pages/forum.php?pid=" . $PID);
                    exit();
                }

                // captcha check
                if($_POST['captcha'] !== $_SESSION['captcha']){
                    $_SESSION['error'] = "Nieprawidłowy rozwiązanie captcha!";
                    header("Location: /pages/forum.php?pid=" . $PID);
                    exit();
                }

                $Body = base64_encode(Filter(filter_input(INPUT_POST, 'body', FILTER_SANITIZE_STRING)));
                $Querry = $DB -> prepare("INSERT INTO comments (post_id, creator, created_date, body) VALUES (:pid, :login, NOW(), :body);");
                $Querry -> bindParam(':pid', $PID);
                $Querry -> bindParam(':login', $_SESSION['login']);
                $Querry -> bindParam(':body', $Body);
                $Querry -> execute();

                $DB = null;
                header("Location: /pages/forum.php?pid=" . $PID);
                exit();
            }

            // delete comment logic
            if(isset($_GET['cdelete']) && isset($_GET['pid'])) {
                // CSRF check
                if(!CheckCSRF('get')){
                    $DB = null;
                    header("Location: /pages/forum.php?pid=" . $_GET['pid']);
                    exit();
                }

                // Verify access
                $CID = filter_input(INPUT_GET, 'cdelete', FILTER_SANITIZE_STRING);
                $Querry = $DB -> prepare("SELECT comments.*, users.level AS level FROM comments JOIN users ON comments.creator = users.login WHERE ID = :cid");
                $Querry -> bindParam(':cid', $CID);
                $Querry -> execute();
                $Comment = $Querry -> fetch(PDO::FETCH_ASSOC);

                if ($Comment['creator'] == $_SESSION['login'] || ($Elevated && $Comment['level'] < $Userlevel)) {
                    $Querry = $DB -> prepare("DELETE FROM comments WHERE ID = :cid");
                    $Querry -> bindParam(':cid', $CID);
                    $Querry -> execute();
                } else {
                    $DB = null;
                    $_SESSION['error'] = "Nie masz uprawnień do usunięcia tego komentarza.";
                    header("Location: /pages/forum.php?pid=" . $_GET['pid']);
                    exit();
                }

                $DB = null;
                header("Location: /pages/forum.php?pid=" . $_GET['pid']);
                exit();
            }

            // add post logic
            if(isset($_POST['edit']) && $_POST['edit'] == 0) {
                // CSRF check
                if(!CheckCSRF()){
                    header("Location: /pages/home.php");
                    exit();
                }

                $Title = base64_encode(Filter(filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING)));
                $Body = base64_encode(Filter(filter_input(INPUT_POST, 'body', FILTER_SANITIZE_STRING)));
                $Querry = $DB -> prepare("INSERT INTO posts (creator, created_date, title, body, edit_level) VALUES (:login, NOW(), :title, :body, :level)");
                $Querry -> bindParam(':login', $_SESSION['login']);
                $Querry -> bindParam(':title', $Title);
                $Querry -> bindParam(':body', $Body);
                $Querry -> bindParam(':level', $Userlevel);
                $Querry -> execute();
                $PostInsert = $Querry -> fetch(PDO::FETCH_ASSOC);
                $PostID = $DB -> lastInsertId();

                // add files to db if present
                if (isset($_FILES['files']) && !empty($_FILES['files']['name'][0])) {
                    $Files = $_FILES['files'];
                    for ($i = 0; $i < count($Files['name']); $i++) {
                        // if file upload failed - skip and continue
                        if ($Files['error'][$i] != 0) {
                            $_SESSION['error'] = 'Wystąpił błąd podczas przesyłania plików!';
                            continue;
                        }

                        // get file info
                        $FileName = $Files['name'][$i];
                        $Extension = strtolower(pathinfo($FileName, PATHINFO_EXTENSION));
                        $FileTMP = $Files['tmp_name'][$i];
                        $FileData = file_get_contents($FileTMP);
                        $FileSize = $Files['size'][$i];

                        // limit size and disable dangerous extensions while allowing all other formats
                        if($FileSize <= $MaxFileSize && !in_array($Extension, $BannedExtensions)) {
                            // upload to db
                            $Querry = $DB -> prepare("INSERT INTO media (uploaded_by, uploaded_on, data, extension) VALUES (:login, NOW(), :data, :ext)");
                            $Querry -> bindParam(':login', $_SESSION['login']);
                            $Querry -> bindParam(':data', $FileData, PDO::PARAM_LOB);
                            $Querry -> bindParam(':ext', $Extension);
                            $Querry -> execute();
                            $MediaID = $DB -> lastInsertId();

                            // link media to post
                            $Querry = $DB -> prepare("INSERT INTO mediaINposts (post_id, media_id) VALUES (:post, :media)");
                            $Querry -> bindParam(':post', $PostID, PDO::PARAM_INT);
                            $Querry -> bindParam(':media', $MediaID, PDO::PARAM_INT);
                            $Querry -> execute();
                        }
                    }
                }
                $DB = null;
                header("Location: /pages/forum.php");
                exit();
            } 

            // edit post logic
            if(isset($_POST['edit']) && $_POST['edit'] == 1 && isset($_POST['id'])) {
                // CSRF check
                if(!CheckCSRF()){
                    header("Location: /pages/forum.php");
                    exit();
                }

                // Get post
                $PID = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_STRING);
                $Querry = $DB -> prepare("SELECT * FROM posts WHERE ID = :pid");
                $Querry -> bindParam(':pid', $PID);
                $Querry -> execute();
                $EditedPost = $Querry -> fetch(PDO::FETCH_ASSOC);

                // Permission check
                if(!$Elevated || $EditedPost['edit_level'] > $Userlevel) {
                    $_SESSION['error'] = "Nie masz uprawnień do edycji tego artykułu.";
                    $DB = null;
                    header("Location: /pages/forum.php");
                    exit();
                }

                // Deletion process
                if(isset($_POST['delete']) && $_POST['delete'] == 1) {
                    // delete comments
                    $Querry = $DB -> prepare("DELETE FROM comments WHERE post_id = :pid");
                    $Querry -> bindParam(':pid', $PID);
                    $Querry -> execute();

                    // assume cached media is regurally erased by extenal script
                    // delete media
                    $Querry = $DB -> prepare("DELETE FROM media WHERE media_id IN (SELECT media_id FROM mediaINposts WHERE post_id = :pid)");
                    $Querry -> bindParam(':pid', $PID);
                    $Querry -> execute();

                    // delete links
                    $Querry = $DB -> prepare("DELETE FROM mediaINposts WHERE post_id = :pid");
                    $Querry -> bindParam(':pid', $PID);
                    $Querry -> execute();

                    // delete the post itself
                    $Querry = $DB -> prepare("DELETE FROM posts WHERE ID = :pid");
                    $Querry -> bindParam(':pid', $PID);
                    $Querry -> execute();

                    $DB = null;
                    header("Location: /pages/forum.php");
                    exit();
                }

                // Otherwise update post
                $NewTitle = base64_encode(Filter(filter_input(INPUT_POST, 'title', FILTER_SANITIZE_STRING)));
                $NewBody = base64_encode(Filter(filter_input(INPUT_POST, 'body', FILTER_SANITIZE_STRING)));
                $Querry = $DB -> prepare("UPDATE posts SET title = :title, body = :body, edit_level = :level, edit_date = NOW(), edited_by = :editor WHERE ID = :pid");
                $Querry -> bindParam(':title', $NewTitle);
                $Querry -> bindParam(':body', $NewBody);
                $Querry -> bindParam(':level', $Userlevel);
                $Querry -> bindParam(':editor', $_SESSION['login']);
                $Querry -> bindParam(':pid', $PID);
                $Querry -> execute();

                $DB = null;
                header("Location: /pages/forum.php?pid=" . $PID);
                exit();
            }

        } catch (PDOException $e) {
            $_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
            //$_SESSION['error'] = $e;
            header("Location: /pages/forum.php");
            exit();
        }
    }
    $DB = null;

    //generate CSRF token
    $CSRFToken = GenerateCSRF();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="settings panel profile user">
        <link rel="icon" href="/assets/favicon64.ico" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/assets/style_common.css">
        <link rel="stylesheet" href="/assets/style_editor.css">
        <link rel="stylesheet" href="/assets/style_forum.css">
        <meta http-equiv="Cache-Control" content="max-age=3600">
        <title>Forum</title>
        <script>
            function closeError() {
                var popup = document.getElementById('error-popup');
                popup.style.display = 'none';
            }
            function openEditor() {
                var blocker = document.getElementById('editor-blocker');
                var editor = document.getElementById('editor');
                var body = document.body;
                blocker.style.display = 'block';
                editor.style.display = 'block';
                body.classList.add('no-scroll');
            }
            function closeEditor() {
                var blocker = document.getElementById('editor-blocker');
                var editor = document.getElementById('editor');
                var body = document.body;
                blocker.style.display = 'none';
                editor.style.display = 'none';
                body.classList.remove('no-scroll');
            }
        </script>
    </head>
    <body>
        <nav class="menu-bar">
            <a href="/pages/chat.php"><div class="menu-item">Chat</div></a>
            <a href="/pages/shop.php"><div class="menu-item">Sklep</div></a>
            <a href="/pages/settings.php"><div class="menu-item">Profil</div></a>
            <?php
                if($Elevated) {
                    echo '<a href="/pages/admin.php"><div class="menu-item">Aministracja</div></a>';
                }
                if(isset($_GET['pid'])) {
                    echo '<a href="/pages/forum.php" style="position: absolute; right: 9vw;"><div class="menu-item">Wróć</div></a>';
                } else {
                    echo '<a href="/pages/home.php" style="position: absolute; right: 9vw;"><div class="menu-item">Strona domowa</div></a>';
                }
            ?>
            <form action="forum.php" method="post" class="logout">
                <input type="hidden" name="logout" value="1">
                <input type="hidden" name="CSRF" value="<?php echo $CSRFToken;?>">
                <input type="submit" id="logout-button" value="Wyloguj się">
            </form>
        </nav>

        <?php
            // Main page - print post list
            if(!isset($_GET['pid'])) { 
                for($i = 0; $i < $PostsPerPage; $i++) {
                    $Post = $PostsDigest -> fetch(PDO::FETCH_ASSOC);
                    if(empty($Post['ID'])) {continue;}

                    echo '<a href="/pages/forum.php?pid='.$Post['ID'].'" class="post-link"><div class="post-widget"><table><tr><td colspan="2" class="post-title">';
                    echo htmlspecialchars(base64_decode($Post['title']), ENT_QUOTES, 'UTF-8');
                    echo '</td></tr><tr><td class="post-author">Twórca: <a href="/pages/profile.php?uid='.$Post['creator_id'].'" class="post-userlink">';
                    echo htmlspecialchars($Post['creator_username'], ENT_QUOTES, 'UTF-8');
                    echo '</a></td><td class="post-editor">';
                    if(!empty($Post['editor_username'])) {
                        echo 'Edycja przez: <a href="/pages/profile.php?uid='.$Post['editor_id'].'" class="post-userlink">';
                        echo htmlspecialchars($Post['editor_username'], ENT_QUOTES, 'UTF-8');
                        echo '</a><br>Dnia: ';
                        echo htmlspecialchars($Post['edit_date'], ENT_QUOTES, 'UTF-8');
                    }
                    echo '</td></tr></table></div></a>';
                }

                // new post button
                echo '<div id="forum-new-post-button" onclick="openEditor()">Nowy</div>';

                // editor - add
                echo '<div id="editor-blocker"><div id="editor"><form action="forum.php" method="post" enctype="multipart/form-data"><div id="editor-close" onclick="closeEditor()">x</div><table id="editor-table">';
                echo '<tr><td id="editor-title-container"><input type="text" name="title" id="editor-title" placeholder="Tytuł"></td></tr>';
                echo '<tr><td><textarea id="editor-body" name="body" placeholder="Wpis"></textarea></td></tr>';
                echo '<tr><td id="editor-files">Dodaj załączniki: <input type="file" name="files[]" multiple></td></tr>';
                echo '<tr><td id="editor-save-container"><input type="hidden" name="CSRF" value="'. $CSRFToken . '">';
                echo '<input type="hidden" name="edit" value="0"><input type="submit" id="editor-save" value="Zapisz"></td></tr></table></form></div></div>';

                // page listing - main
                echo '<div id="page-listing">';
                $PagesNum = ceil($PostsTotal['total'] / $PostsPerPage);
                for($i = 1; $i <= $PagesNum; $i++) {
                    echo '<a href="/pages/forum.php?page='.$i.'" class="page-link"><div class="page-number">'.$i.'</div></a>';
                }
                echo '</div>';
            }

            // inside post view
            if(isset($_GET['pid'])) {
                echo '<div id="post-full"><table><tr><td id="post-title">';
                echo htmlspecialchars(base64_decode($Post['title']), ENT_QUOTES, 'UTF-8');
                echo '</td></tr><tr><td id="post-body">';
                echo '<pre>'.htmlspecialchars(base64_decode($Post['body']), ENT_QUOTES, 'UTF-8').'</pre>';
                echo '</td></tr><tr><td id="post-media"><ul>';
                for($i = 0; $i < $MediaListLen; $i++) {
                    if(empty($MediaList[$i][0])){continue;}
                    echo '<a href="/media/'.$MediaList[$i][0] . '.' . $MediaList[$i][1].'"><li class="post-media-link">'.htmlspecialchars($MediaList[$i][0] . '.' . $MediaList[$i][1], ENT_QUOTES, 'UTF-8').'</li></a>';
                }
                echo '</ul></td></tr><tr><td id="post-credits"><div id="post-author">';
                echo 'Autor: <a href=/pages/profile.php?uid='.htmlspecialchars($Post['creator_id'], ENT_QUOTES, 'UTF-8').' class="post-userlink">'.htmlspecialchars($Post['creator_username'], ENT_QUOTES, 'UTF-8').'</a>';
                echo '</div>';
                if(!empty($Post['editor_username'])) {
                    echo '<div id="post-editor">';
                    echo 'Edycja przez: <a href=/pages/profile.php?uid='.htmlspecialchars($Post['editor_id'], ENT_QUOTES, 'UTF-8').' class="post-userlink">'.htmlspecialchars($Post['editor_username'], ENT_QUOTES, 'UTF-8').'</a>';
                    echo ', Dnia: '.htmlspecialchars($Post['edit_date'], ENT_QUOTES, 'UTF-8');
                    echo '</div>';
                }
                echo '</td></tr></table></div>';

                // edit post
                if(($Elevated || $Post['creator'] == $_SESSION['login']) && $Userlevel >= $Post['edit_level']) {
                    // edit button
                    echo '<div id="forum-new-post-button" onclick="openEditor()">Edytuj</div>';
                    // editor - edit
                    echo '<div id="editor-blocker"><div id="editor"><form action="forum.php" method="post"><div id="editor-close" onclick="closeEditor()">x</div><table id="editor-table">';
                    echo '<tr><td id="editor-title-container"><input type="text" name="title" id="editor-title" placeholder="Tytuł" value="'.htmlspecialchars(base64_decode($Post['title']), ENT_QUOTES, 'UTF-8').'"></td></tr>';
                    echo '<tr><td><textarea id="editor-body" name="body" placeholder="Wpis">'.htmlspecialchars(base64_decode($Post['body']), ENT_QUOTES, 'UTF-8').'</textarea></td></tr>';
                    echo '<tr><td><input type="checkbox" name="delete" value="1">Usunąć?</td></tr>';
                    echo '<tr><td id="editor-save-container"><input type="hidden" name="CSRF" value="'. $CSRFToken . '">';
                    echo '<input type="hidden" name="id" value="'. $Post['ID'] . '">';
                    echo '<input type="hidden" name="edit" value="1"><input type="submit" id="editor-save" value="Zapisz"></td></tr></table></form></div></div>';
                }

                // list comments
                for($i = 0; $i < $CommentsPerPage; $i++) {
                    $Comment = $CommentDigest -> fetch(PDO::FETCH_ASSOC);
                    if(empty($Comment['ID'])) {continue;}

                    echo '<div class="comment"><table><tr><td class="comment-author">';
                    echo 'Od: <a class="post-userlink" href="/pages/profile.php?uid='.$Comment['creator_id'].'">' . htmlspecialchars($Comment['creator_username'], ENT_QUOTES, 'UTF-8') . '</a>';
                    echo '</td><td class="comment-date">';
                    echo 'Dnia: ' . htmlspecialchars($Comment['created_date'], ENT_QUOTES, 'UTF-8');

                    if($Comment['creator'] == $_SESSION['login'] || ($Comment['level'] < $Userlevel && $Elevated)) {
                        echo '</td><td class="comment-delete">';
                        echo '<a href="?pid=' . $PID . '&cdelete=' . $Comment['ID'] . '&CSRF=' . $CSRFToken . '" class="post-userlink" style="color:inherit;">Usuń</a>';
                        echo '</td>';
                    }

                    echo '</tr><tr><td colspan="3" class="comment-body">';
                    echo '<pre>' . htmlspecialchars(base64_decode($Comment['body']), ENT_QUOTES, 'UTF-8') . '</pre>';
                    echo '</td></tr></table></div>';
                }

                // new comment form
                echo '<div id="comment-add"><form action="forum.php" method="post"><table><tr><td rowspan="2" id="comment-add-body">';
                echo '<textarea placeholder="Komentarz" name="body"></textarea>';
                echo '</td><td id="comment-add-captcha">';
                echo '<img src="?captcha=" alt="???" id="captcha_img" onclick="document.getElementById(\'captcha_img\').src=\'?captcha=\'+Math.random();" />';
                echo '</td><tr><td id="comment-add-submit">';
                echo '<input type="hidden" name="CSRF" value="' . $CSRFToken . '">';
                echo '<input type="hidden" name="id" value="' . $PID . '">';
                echo '<input type="hidden" name="addcomment" value="1">';
                echo '<input type="text" name="captcha" placeholder="Rozwiązanie captcha" id="comment-new-captcha-input">';
                echo '<input type="submit" value="Wyślij" id="comment-new-submit">';
                echo '</td></tr></table></form></div>';

                // page listing for comments
                if(isset($_GET['pid'])) {
                    // Page listing
                    echo '<div id="page-listing">';
                    $PagesNum = ceil($CommentsTotal['total'] / $CommentsPerPage);
                    for($i = 1; $i <= $PagesNum; $i++) {
                        echo '<a href="/pages/forum.php?pid='.$PID.'&page='.$i.'" class="page-link"><div class="page-number">'.$i.'</div></a>';
                    }
                    echo '</div>';
                }
            }

            // error message
            if(!empty($_SESSION['error'])) {
                echo "<div id=\"error-popup\">";
                echo "<button class=\"error-close\" onclick=\"closeError()\">x</button>";
                echo "<p id=\"error-message\">" . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . "</p>";
                echo "</div>";
                unset($_SESSION['error']);
            }
        ?>
    </body>
</html>