<?php
    // generate captcha on demand
    if(isset($_GET['captcha'])) {
        require("../functions/captcha.php");
        GenerateCaptchaImage();
        exit();
    }

    // if already logged in, redirect to home
    session_start();
    if (isset($_SESSION['login'])) {
        header("Location: /pages/home.php");
        exit();
    }

    // import CSRF utility
    require("../functions/csrf.php");

    // attempt login
    if(isset($_POST['CSRF'])) {
        // field checks
        if(!isset($_POST['login'])){
            $_SESSION['error'] = "Wymagane pole - login.";
            header("Location: /pages/login.php");
            exit();
        }
        if(!isset($_POST['password'])){
            $_SESSION['error'] = "Wymagane pole - hasło.";
            header("Location: /pages/login.php");
            exit();
        }
        if(!isset($_POST['captcha'])){
            $_SESSION['error'] = "Wymagane pole - captcha.";
            header("Location: /pages/login.php");
            exit();
        }

        // CSRF check
        if(!CheckCSRF()){
            $_SESSION['error'] = "Bład formularza! Spróbuj ponownie.";
            header("Location: /pages/login.php");
            exit();
        }

        // captcha check
        if($_POST['captcha'] !== $_SESSION['captcha']){
            $_SESSION['error'] = "Nieprawidłowy rozwiązanie captcha!";
            header("Location: /pages/login.php");
            exit();
        }

        // lookup login info
        try {
            $Login = filter_input(INPUT_POST, 'login', FILTER_SANITIZE_STRING);
            require("../config/db.php");
            $DB = new PDO("mysql:host=$DBhost;dbname=$DBname", $DBuser, $DBpass);
            $DB -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $Querry = $DB -> prepare("SELECT * FROM users WHERE login = :login");
            $Querry -> bindParam(':login', $Login);
            $Querry -> execute();
            $Record = $Querry -> fetch(PDO::FETCH_ASSOC);
            if($Record) {
                // perma ban check
                if($Record['permaban'] == true) {
                    $_SESSION['error'] = "Konto zostało pernamentnie zbanowane!";
                    header("Location: /pages/login.php");
                    exit();
                }

                // regular ban check
                if($Record['active'] == false) {
                    // check if can be unbanned assuming the only trusted timer is the database
                    $Querry = $DB -> prepare("SELECT ban, CURDATE() > ban AS 'check' FROM users WHERE login = :login");
                    $Querry -> bindParam(':login', $Login);
                    $Querry -> execute();
                    $Check = $Querry -> fetch(PDO::FETCH_ASSOC);
                    if($Check['check'] == true){
                        // unban
                        $Querry = $DB -> prepare("UPDATE users SET active = true, ban = NULL WHERE login = :login");
                        $Querry -> bindParam(':login', $Login);
                        $Querry -> execute();
                    } else {
                        if(!empty($Check['ban'])){
                            $_SESSION['error'] = "Konto jest zbanowane do ".$Check['ban'].".";
                        } else {
                            $_SESSION['error'] = "Konto zostało deaktywowane!";
                        }
                        header("Location: /pages/login.php");
                        exit();
                    }
                }

                // password check
                if (password_verify($_POST['password'], $Record['password'])){
                    // password is ok
                    $_SESSION['login'] = $Record['login'];
                    $_SESSION['username'] = $Record['username'];
                    header("Location: /pages/home.php");

                    // save last logged in ip and time
                    $Querry = $DB -> prepare("UPDATE users SET last_ip = :last_ip, last_login = NOW() WHERE login = :login");
                    $Querry -> bindParam(':last_ip', $_SERVER['REMOTE_ADDR']);
                    $Querry -> bindParam(':login', $Login);
                    $Querry -> execute();

                    // terminate database connection when login success
                    $DB = null;
                    exit();
                } else {
                    // password is wrong but keep it ambiguous
                    $_SESSION['error'] = "Niewłasciwy login lub hasło!";
                    header("Location: /pages/login.php");
                    exit();
                }
            } else {
                // given account does not exist
                $_SESSION['error'] = "Niewłasciwy login lub hasło!";
                header("Location: /pages/login.php");
                exit();
            }

        } catch (PDOException $e) {
            $_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
            //$_SESSION['error'] = $e;
            header("Location: /pages/login.php");
            exit();
        }
    }
    $DB = null;

    // custom message used for ban info
    if(isset($_GET['msg'])) {
        $_SESSION['error'] = base64_decode($_GET['msg']);
    }

    //generate CSRF token
    $CSRFToken = GenerateCSRF();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="login panel">
        <link rel="icon" href="/assets/favicon64.ico" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/assets/style_common.css">
        <link rel="stylesheet" href="/assets/style_login.css">
        <meta http-equiv="Cache-Control" content="max-age=3600">
        <title>Panel logowania</title>
    </head>
    <body>
        <div id="login-container">
            <form action="/pages/login.php" method="post">
                <table>
                    <tr>
                        <td><input type="text" name="login" placeholder="Login" required></td>
                    </tr>
                    <tr>
                        <td><input type="password" name="password" placeholder="Hasło" required></td>
                    </tr>
                    <tr>
                        <td><img src="?captcha=" alt="???" id="captcha_img" onclick="document.getElementById('captcha_img').src='?captcha='+Math.random();" style="width:80%;" /></td>
                    </tr>
                    <tr>
                        <td><input type="text" id="captcha" name="captcha" placeholder="Captcha" required></td>
                    </tr>
                    <?php
                        if(isset($_SESSION['error'])){
                            echo('
                                <tr>
                                    <td><span class="error">'. htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') .'</span></td>
                                </tr>
                            ');
                            unset($_SESSION['error']);
                        }
                    ?>
                    <tr>
                        <td>
                            <input type="hidden" name="CSRF" value="<?php echo $CSRFToken;?>">
                            <input type="submit" value="Zaloguj się">
                        </td>
                    </tr>
                    <tr>
                        <td><a href="/pages/register.php"><p id="join-link">Nie masz jeszcze konta?</p></a></td>
                    </tr>
                </table>
            </form>
        </div>

        <footer id="basic-footer">
            <span>Dla nowych użytkowników zalecane jest przeczytanie <a href="/documents/regulamin.pdf">regulaminu</a>, oraz <a href="/documents/user-manual.pdf">poradnika nowego użytkownika</a>.</span>
        </footer>
    </body>
</html>