<?php
    // if not logged in - redirect to login
    session_start();
    if (!isset($_SESSION['login'])) {
        header("Location: /pages/login.php");
        exit();
    }

    // is user id given?
    if(!isset($_GET['uid'])) {
        $_SESSION['error'] = "Nie znaleziono profilu!";
        header("Location: /pages/home.php");
        exit();
    }

    // import CSRF utility
    require("../functions/csrf.php");

    // logout
    require("../functions/logout.php");
    if(isset($_POST['logout'])) {
        // CSRF check
        if(!CheckCSRF()){
            header("Location: /pages/home.php");
            exit();
        }

        // logout
        Logout();
        exit();
    }

    // database operations
    if(!(isset($_SESSION['error']) && $_SESSION['error'] === "Wystąpił błąd serwera, spróbój ponownie później.")){
        try {
            require("../config/db.php");
            $DB = new PDO("mysql:host=$DBhost;dbname=$DBname", $DBuser, $DBpass);
            $DB -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $Querry = $DB -> prepare("SELECT level, permaban, ban, active, CASE WHEN ban IS NULL THEN 0 ELSE 1 END AS isbanned, extension FROM users LEFT JOIN media ON profile_pic = media_id WHERE login = :login");
            $Querry -> bindParam(':login', $_SESSION['login']);
            $Querry -> execute();
            $Record = $Querry -> fetch(PDO::FETCH_ASSOC);
            $Userlevel = $Record['level'];

            // is permabanned?
            if($Record['permaban'] != 0) {
                Logout("Konto zostało pernamentnie zbanowane!");
                $DB = null;
                exit();
            }

            // is regular ban or deactivated?
            if($Record['active'] != 1) {
                if(!empty($Record['ban'])) {
                    Logout("Konto jest zbanowane do ".$Record['ban'].".");
                } else {
                    Logout("Konto zostało deaktywowane!");
                }
                $DB = null;
                exit();
            }

            // should the admin panel option be shown?
            if($Record['level'] >= 100) {$Elevated = true;} else {$Elevated = false;}

            // lookup user
            $ID = filter_input(INPUT_GET, 'uid', FILTER_SANITIZE_STRING);
            $Querry = $DB -> prepare("SELECT * FROM users WHERE external_id = :id");
            $Querry -> bindParam(':id', $ID);
            $Querry -> execute();
            $User = $Querry -> fetch(PDO::FETCH_ASSOC);

            // Load profile picture from DB to web server if not already loaded
            $Querry = $DB -> prepare("SELECT extension FROM media WHERE media_id = :id");
            $Querry -> bindParam(':id', $User['profile_pic']);
            $Querry -> execute();
            $Extension = $Querry -> fetch(PDO::FETCH_ASSOC);

            $MediaDIR = $_SERVER['DOCUMENT_ROOT'] . '/media/';
            $MediaFile = $MediaDIR . $User['profile_pic'] . "." . $Extension['extension'];
            if (!file_exists($MediaFile)) {
                $Querry = $DB -> prepare("SELECT data FROM media WHERE media_id = :id");
                $Querry -> bindParam(':id', $User['profile_pic']);
                $Querry -> execute();
                $Record = $Querry -> fetch(PDO::FETCH_ASSOC);
                if ($Record['data']) {
                    file_put_contents($MediaFile, $Record['data']);
                } else {
                    // media not in db?
                    //$_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
                    //$DB = null;
                    //header("Location: /pages/home.php");
                    //exit();
                }
            }
            
        } catch (PDOException $e) {
            $_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
            //$_SESSION['error'] = $e;
            header("Location: /pages/home.php");
            exit();
        }
    }
    $DB = null;

    // set image path
    if (empty($User['profile_pic'])) {
        $ImagePath = "/assets/null.png";
    } else {
        $ImagePath = "/media/" . $User['profile_pic'] . '.' . $Extension['extension'];
    }

    //generate CSRF token
    $CSRFToken = GenerateCSRF();

?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="settings panel profile user">
        <link rel="icon" href="/assets/favicon64.ico" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/assets/style_common.css">
        <link rel="stylesheet" href="/assets/style_profile.css">
        <meta http-equiv="Cache-Control" content="max-age=3600">
        <title>Profil użytkownika</title>
    </head>
    <body>
        <nav class="menu-bar">
            <a href="/pages/forum.php"><div class="menu-item">Forum</div></a>
            <a href="/pages/chat.php"><div class="menu-item">Chat</div></a>
            <a href="/pages/shop.php"><div class="menu-item">Sklep</div></a>
            <a href="/pages/settings.php"><div class="menu-item">Profil</div></a>
            <?php
                if($Elevated) {
                    echo '<a href="/pages/admin.php"><div class="menu-item">Aministracja</div></a>';
                }
            ?>
            <a href="/pages/home.php" style="position: absolute; right: 9vw;"><div class="menu-item">Strona domowa</div></a>
            <form action="settings.php" method="post" class="logout">
                <input type="hidden" name="logout" value="1">
                <input type="hidden" name="CSRF" value="<?php echo $CSRFToken;?>">
                <input type="submit" id="logout-button" value="Wyloguj się">
            </form>
        </nav>

        <div id="profile-container">
            <table id="container-table">
                <tr>
                    <td id="profile-img-container">
                        <img src="<?php echo $ImagePath ?>" alt="404" />
                    </td>
                    <td id="profile-description-container">
                        <div class="profile-title">Informacje:</div>
                        <br>
                        <div id="profile-info-container">
                            <?php 
                                echo '<span>Nazwa użytkownika: <span style="color: black; font-weight: 700;">' . htmlspecialchars($User['username'], ENT_QUOTES, 'UTF-8') . '</span><br>';

                                if($User['active'] == 1) {
                                    $Active = '<span style="color: green; font-weight: 700;">Tak</span>';
                                } else {
                                    $Active = '<span style="color: red; font-weight: 700;">Nie</span>';
                                }
                                echo 'Aktywny: ' . $Active . '<br>';

                                switch (true) {
                                    case $User['level'] >= 1000:
                                        $Role = '<span style="color: darkgreen; font-weight: 700;">Operator</span>';
                                        break;
                                    case $User['level'] >= 500:
                                        $Role = '<span style="color: red; font-weight: 700;">Administrator</span>';
                                        break;
                                    case $User['level'] >= 100:
                                        $Role = '<span style="color: yellow; font-weight: 700;">Moderator</span>';
                                        break;
                                    default:
                                        $Role = '<span style="color: lightgray; font-weight: 700;">Użytkownik</span>';
                                        break;
                                }
                                echo 'Rola: ' . $Role;

                                // display extra info
                                // only for higher role or operator
                                if($Userlevel > $User['level'] || $Userlevel >= 1000) {
                                    echo '<br><br><br>';
                                    echo 'Ostatnio zalogowany: <span style="color: black; font-weight: 700;">' . htmlspecialchars($User['last_login'], ENT_QUOTES, 'UTF-8') . '</span><br>';
                                    echo 'Z adresu IP: <span style="color: black; font-weight: 700;">' . htmlspecialchars($User['last_ip'], ENT_QUOTES, 'UTF-8') . '</span><br>';
                                }
                                echo '</span>';
                            ?>
                        </div>
                        <br>
                        <div class="profile-title">Opis:</div>
                        <br>
                        <div id="description">
                            <pre><?php echo htmlspecialchars(base64_decode($User['description']), ENT_QUOTES, 'UTF-8') ?></pre>
                        </div>
                    </td>
                </tr>
            </table>
        </div>

    </body>
</html>