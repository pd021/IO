<?php
    // if not logged in - redirect to login
    session_start();
    if (!isset($_SESSION['login'])) {
        header("Location: /pages/login.php");
        exit();
    }

    // import CSRF utility
    require("../functions/csrf.php");

    // logout
    require("../functions/logout.php");
    if(isset($_POST['logout'])) {
        // CSRF check
        if(!CheckCSRF()){
            header("Location: /pages/home.php");
            exit();
        }

        // logout
        Logout();
        exit();
    }

    // database lookups
    if(!(isset($_SESSION['error']) && $_SESSION['error'] === "Wystąpił błąd serwera, spróbój ponownie później.")){ 
        try {
            require("../config/db.php");
            $DB = new PDO("mysql:host=$DBhost;dbname=$DBname", $DBuser, $DBpass);
            $DB -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $Querry = $DB -> prepare("SELECT login, external_id, level, permaban, ban, active, CASE WHEN ban IS NULL THEN 0 ELSE 1 END AS isbanned FROM users WHERE login = :login");
            $Querry -> bindParam(':login', $_SESSION['login']);
            $Querry -> execute();
            $CurrentUser = $Querry -> fetch(PDO::FETCH_ASSOC);

            // is permabanned?
            if($CurrentUser['permaban'] != 0) {
                Logout("Konto zostało pernamentnie zbanowane!");
                $DB = null;
                exit();
            }

            // is regular ban or deactivated?
            if($CurrentUser['active'] != 1) {
                if(!empty($CurrentUser['ban'])) {
                    Logout("Konto jest zbanowane do ".$CurrentUser['ban'].".");
                } else {
                    Logout("Konto zostało deaktywowane!");
                }
                $DB = null;
                exit();
            }

            // permission check
            if($CurrentUser['level'] < 100) {
                $_SESSION['error'] = "Nie masz uprawnień do tej strony!";
                $DB = null;
                header("Location: /pages/home.php");
                exit();
            }

            // mute / unmute
            if(isset($_GET['ircmute'])) {
                $UID = filter_input(INPUT_GET, 'uid', FILTER_SANITIZE_STRING);
                $UserLookup = $DB -> prepare("SELECT * FROM users WHERE external_id = :uid");
                $UserLookup -> bindParam(':uid', $UID);
                $UserLookup -> execute();
                $UserRecord = $UserLookup -> fetch(PDO::FETCH_ASSOC);

                // permission check
                if(($UserRecord['level'] < $CurrentUser['level'] && $CurrentUser['level'] >= 100) || $CurrentUser['level'] >= 1000) {
                    // CSRF check
                    if(!CheckCSRF('get')){
                        header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                        exit();
                    }

                    // unmute
                    if($_GET['ircmute'] == 0) {
                        $UserAction = $DB -> prepare("UPDATE users SET ircbanned = 0 WHERE external_id = :uid");
                        $UserAction -> bindParam(':uid', $UID);
                        $UserAction -> execute();
                    }
                    // mute
                    else if($_GET['ircmute'] == 1) {
                        $UserAction = $DB -> prepare("UPDATE users SET ircbanned = 1 WHERE external_id = :uid");
                        $UserAction -> bindParam(':uid', $UID);
                        $UserAction -> execute();
                    }
                } else {
                    $_SESSION['error'] = "Nie posiadasz wystarczających uprawnień!";
                    $DB = null;
                    header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                    exit();
                }
                $DB = null;
                header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                exit();
            }

            // ban
            if(isset($_POST['ban']) && $_POST['ban'] == 1) {
                $UID = filter_input(INPUT_GET, 'uid', FILTER_SANITIZE_STRING);
                $UserLookup = $DB -> prepare("SELECT * FROM users WHERE external_id = :uid");
                $UserLookup -> bindParam(':uid', $UID);
                $UserLookup -> execute();
                $UserRecord = $UserLookup -> fetch(PDO::FETCH_ASSOC);

                if(($UserRecord['level'] < $CurrentUser['level'] && $CurrentUser['level'] >= 100) || $CurrentUser['level'] >= 1000) {
                    // CSRF check
                    if(!CheckCSRF()){
                        header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                        exit();
                    }

                    // perma
                    if(isset($_POST['pernament']) && $_POST['pernament'] == 1){
                        // only administrators and above can permaban
                        if($CurrentUser['level'] < 500) {
                            $_SESSION['error'] = "Nie posiadasz wystarczających uprawnień!";
                            $DB = null;
                            header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                            exit();
                        }

                        $UserBanAction = $DB -> prepare("UPDATE users SET active = false, permaban = true, ban = NULL WHERE external_id = :uid");
                        $UserBanAction -> bindParam(':uid', $UID);
                        $UserBanAction -> execute();

                        $DB = null;
                        header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                        exit();
                    }

                    //normal ban
                    if(isset($_POST['bantime'])) {
                        // don't allow unban to non admins if pernament
                        if($UserRecord['permaban'] == 1 && $CurrentUser['level'] < 500) {
                            $_SESSION['error'] = "Nie posiadasz wystarczających uprawnień!";
                            $DB = null;
                            header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                            exit();
                        }

                        // bad format
                        if(!is_numeric($_POST['bantime']) || (int) $_POST['bantime'] != $_POST['bantime']) {
                            $_SESSION['error'] = "Nieprawidłowa wartość!";
                            $DB = null;
                            header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                            exit();
                        }

                        $BanTime = filter_input(INPUT_POST, 'bantime', FILTER_SANITIZE_STRING);
                        if($BanTime == 0) {
                            $UserBanAction = $DB -> prepare("UPDATE users SET active = true, permaban = false, ban = NULL WHERE external_id = :uid");
                            $UserBanAction -> bindParam(':uid', $UID);
                            $UserBanAction -> execute();
                        } else {
                            $UserBanAction = $DB -> prepare("SELECT NOW() AS time");
                            $UserBanAction -> execute();
                            $FetchTime = $UserBanAction -> fetch(PDO::FETCH_ASSOC);
                            $CurrentTime = $FetchTime['time'];

                            $NewTime = new DateTime($CurrentTime);
                            $NewTime -> modify("+$BanTime hours");
                            $NewDatetime = $NewTime -> format('Y-m-d H:i:s');

                            $UserBanAction = $DB -> prepare("UPDATE users SET active = false, permaban = false, ban = :time WHERE external_id = :uid");
                            $UserBanAction -> bindParam(':time', $NewDatetime);
                            $UserBanAction -> bindParam(':uid', $UID);
                            $UserBanAction -> execute();
                        }
                    }
                } else {
                    $_SESSION['error'] = "Nie posiadasz wystarczających uprawnień!";
                    $DB = null;
                    header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                    exit();
                }
                $DB = null;
                header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                exit();
            }

            // change role
            if(isset($_POST['upgrade']) && $_POST['upgrade'] == 1) {
                // CSRF check
                if(!CheckCSRF()){
                    header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                    exit();
                }

                // level check
                if($CurrentUser['level'] < 500) {
                    $_SESSION['error'] = "Nie posiadasz wystarczających uprawnień!";
                    $DB = null;
                    header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                    exit();
                }

                $UID = filter_input(INPUT_GET, 'uid', FILTER_SANITIZE_STRING);
                $UserLookup = $DB -> prepare("SELECT * FROM users WHERE external_id = :uid");
                $UserLookup -> bindParam(':uid', $UID);
                $UserLookup -> execute();
                $UserRecord = $UserLookup -> fetch(PDO::FETCH_ASSOC);

                // self check
                if($CurrentUser['login'] == $UserRecord['login']) {
                    $_SESSION['error'] = "Nie możesz zmieniać własnych uprawnień!";
                    $DB = null;
                    header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                    exit();
                }

                // seniority check (not applicable for operators)
                if($CurrentUser['level'] <= $UserRecord['level'] && $CurrentUser['level'] < 1000) {
                    $_SESSION['error'] = "Nie posiadasz wystarczających uprawnień!";
                    $DB = null;
                    header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                    exit();
                }

                $Role = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_STRING);
                
                switch($Role) {
                    case 'user':
                        $Level = 0;
                        break;
                    case 'moderator':
                        $Level = 100;
                        break;
                    case 'admin':
                        $Level = 500;
                        break;
                    case 'operator':
                        $Level = 1000;
                        break;
                    default:
                        $Level = 0;
                        break;
                }

                // admins can only assign moderators
                if ($CurrentUser['level'] <= 500 && $Level > 100) {
                    $_SESSION['error'] = "Nie posiadasz wystarczających uprawnień!";
                    $DB = null;
                    header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                    exit();
                }

                $UserUpgrade = $DB -> prepare("UPDATE users SET level = :level WHERE login = :login");
                $UserUpgrade -> bindParam(':level', $Level);
                $UserUpgrade -> bindParam(':login', $UserRecord['login']);
                $UserUpgrade -> execute();

                $DB = null;
                header("Location: /pages/admin.php?usersearch=".$_GET['usersearch']);
                exit();
            }

            // user search
            if(isset($_GET['usersearch']) && !empty($_GET['usersearch'])) {
                $Search = strtolower(filter_input(INPUT_GET, 'usersearch', FILTER_SANITIZE_STRING));
                $Search = '%'.$Search.'%';
                $UsersQuerry = $DB -> prepare("SELECT users.*, media.extension FROM users LEFT JOIN media ON users.profile_pic = media.media_id HAVING login LIKE :search UNION SELECT users.*, media.extension FROM users LEFT JOIN media ON users.profile_pic = media.media_id HAVING username LIKE :search");
                $UsersQuerry -> bindParam(':search', $Search);
                $UsersQuerry -> execute();
            } else {
                $UsersQuerry = NULL;
            }


        } catch (PDOException $e) {
            //$_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
            $_SESSION['error'] = $e;
            header("Location: /pages/home.php");
            exit();
        }
    }

    //generate CSRF token
    $CSRFToken = GenerateCSRF();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="login panel">
        <link rel="icon" href="/assets/favicon64.ico" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/assets/style_common.css">
        <link rel="stylesheet" href="/assets/style_admin.css">
        <meta http-equiv="Cache-Control" content="max-age=3600">
        <title>Panel Administracyjny</title>
        <script>
            function closeError() {
                var popup = document.getElementById('error-popup');
                popup.style.display = 'none';
            }
        </script>
    </head>
    <body>
        <nav class="menu-bar">
            <a href="/pages/forum.php"><div class="menu-item">Forum</div></a>
            <a href="/pages/chat.php"><div class="menu-item">Chat</div></a>
            <a href="/pages/shop.php"><div class="menu-item">Sklep</div></a>
            <a href="/pages/settings.php"><div class="menu-item">Profil</div></a>
            <form action="admin.php" method="post" class="logout">
                <input type="hidden" name="logout" value="1">
                <input type="hidden" name="CSRF" value="<?php echo $CSRFToken;?>">
                <input type="submit" id="logout-button" value="Wyloguj się">
            </form>
        </nav>

        <div id="user-list-container">
            <form action="admin.php" method="get">
                <input type="text" name="usersearch" id="user-search-input" value=<?php echo $_GET['usersearch']; ?>>
                <input type="submit" id="user-search-button" value="Wyszukaj">
            </form>
            <div id="user-list">
                <?php
                    try {
                        $UserData = $UsersQuerry -> fetch(PDO::FETCH_ASSOC);
                        while(!empty($UserData['login'])) {
                            echo '<div class="user-listing"><table border><tr><td class="user-listing-image" rowspan="4">';

                            $ImagePath = '/media/' . $UserData['profile_pic'] . "." . $UserData['extension'];
                            $MediaDIR = $_SERVER['DOCUMENT_ROOT'] . '/media/';
                            $MediaFile = $MediaDIR . $UserData['profile_pic'] . "." . $UserData['extension'];
                            if (!file_exists($MediaFile)) {
                                $Querry = $DB -> prepare("SELECT data FROM media WHERE media_id = :id");
                                $Querry -> bindParam(':id', $UserData['profile_pic']);
                                $Querry -> execute();
                                $Record = $Querry -> fetch(PDO::FETCH_ASSOC);
                                if ($Record['data']) {
                                    file_put_contents($MediaFile, $Record['data']);
                                    $ImagePath = '/media/' . $UserData['profile_pic'] . "." . $UserData['extension'];
                                } else {
                                    $ImagePath = '/assets/null.png';
                                }
                            }
                            if (empty($UserData['profile_pic'])) {
                                echo '<a href="/pages/profile.php?uid='.$UserData['external_id'].'"><img src="/assets/null.png" alt="404" /></a>'; // IMAGE AND LINK
                            } else {
                                echo '<a href="/pages/profile.php?uid='.$UserData['external_id'].'"><img src="'.$ImagePath.'" alt="404" /></a>'; // IMAGE AND LINK
                            }
                            echo '</td><td class="user-listing-info">';

                            // LOGIN
                            if($CurrentUser['level'] > $UserData['level'] || $CurrentUser['level'] >= 1000) {
                                echo '<b>Login: </b>'.htmlspecialchars($UserData['login'], ENT_QUOTES, 'UTF-8');
                            } else {
                                echo '<b>Login: </b>XXXXXXXX';
                            }
                            echo '</td><td class="user-listing-info">';

                            // ARTICLE COUNT
                            $Querry = $DB -> prepare("SELECT COUNT(*) AS count FROM news WHERE creator = :login");
                            $Querry -> bindParam(':login', $UserData['login']);
                            $Querry -> execute();
                            $Count = $Querry -> fetch(PDO::FETCH_ASSOC);
                            echo '<b>Liczba artykułów: </b>'.$Count['count'];
                            echo '</td>';
                            
                            // IRC MUTE
                            switch (true) {
                                case $UserData['ircbanned'] == 1:
                                    $IRC = '<a href="/pages/admin.php?ircmute=0&uid='.$UserData['external_id'].'&CSRF='.$CSRFToken.'&usersearch='.$_GET['usersearch'].'"><span style="color: red; font-weight: 700;">Tak</span></a>';
                                    break;
                                case $UserData['ircbanned'] == 0:
                                    $IRC = '<a href="/pages/admin.php?ircmute=1&uid='.$UserData['external_id'].'&CSRF='.$CSRFToken.'&usersearch='.$_GET['usersearch'].'"><span style="color: green; font-weight: 700;">Nie</span></a>';
                                    break;
                                default:
                                    $IRC = '<a href="/pages/admin.php?ircmute=1&uid='.$UserData['external_id'].'&CSRF='.$CSRFToken.'&usersearch='.$_GET['usersearch'].'"><span style="color: green; font-weight: 700;">Nie</span></a>';
                                    break;
                            }
                            echo '<td class="user-config-irc"><b>Wyciszony: </b>'.$IRC;
                            echo '</td>';

                            echo '</tr><tr><td class="user-listing-info">';

                            // USERNAME
                            echo '<b>Nazwa Użytkownika: </b>'.htmlspecialchars($UserData['username'], ENT_QUOTES, 'UTF-8');
                            echo '</td><td class="user-listing-info">';

                            // POST COUNT
                            $Querry = $DB -> prepare("SELECT COUNT(*) AS count FROM posts WHERE creator = :login");
                            $Querry -> bindParam(':login', $UserData['login']);
                            $Querry -> execute();
                            $Count = $Querry -> fetch(PDO::FETCH_ASSOC);
                            echo '<b>Liczba postów: </b>'.$Count['count'];
                            echo '</td>';

                            // BAN INFO
                            switch (true) {
                                case $UserData['active'] == 1:
                                    $Locked = '<span style="color: green; font-weight: 700;">Nie</span>';
                                    break;
                                case $UserData['active'] == 0:
                                    if($UserData['permaban'] == 1) {
                                        $Locked = '<span style="color: red; font-weight: 700;">Tak</span> - Pernamentnie';
                                    }
                                    else if($UserData['permaban'] == 0 && !empty($UserData['ban'])) {
                                        $Locked = '<span style="color: red; font-weight: 700;">Tak</span> - '.$UserData['ban'];
                                    }
                                    else {
                                        $Locked = '<span style="color: red; font-weight: 700;">Tak</span> - Konto deaktywowane';
                                    }
                                    break;
                                default:
                                    $Locked = '<span style="color: green; font-weight: 700;">Nie</span>';
                                    break;
                            }
                            echo '<td class="ban-info"><b>Konto zablokowane?: </b>'.$Locked.'<br></td>';
                            
                            echo '</tr><tr><td class="user-listing-info">';

                            // ROLE
                            switch (true) {
                                case $UserData['level'] >= 1000:
                                    $Role = '<span style="color: darkgreen; font-weight: 700;">Operator</span>';
                                    break;
                                case $UserData['level'] >= 500:
                                    $Role = '<span style="color: red; font-weight: 700;">Administrator</span>';
                                    break;
                                case $UserData['level'] >= 100:
                                    $Role = '<span style="color: yellow; font-weight: 700;">Moderator</span>';
                                    break;
                                default:
                                    $Role = '<span style="color: lightgray; font-weight: 700;">Użytkownik</span>';
                                    break;
                            }
                            echo '<b>Rola: </b>'.$Role; 
                            echo '</td><td class="user-listing-info">';

                            // COMMENT COUNT
                            $Querry = $DB -> prepare("SELECT COUNT(*) AS count FROM comments WHERE creator = :login");
                            $Querry -> bindParam(':login', $UserData['login']);
                            $Querry -> execute();
                            $Count = $Querry -> fetch(PDO::FETCH_ASSOC);
                            echo '<b>Liczba komentarzy: </b>'.$Count['count']; 
                            echo '</td>';

                            // Change role
                            echo '<td class="user-config-role"><b>Zmień rolę: </b><br>';
                            echo '<form action="admin.php?uid='.$UserData['external_id'].'&usersearch='.$_GET['usersearch'].'" method="post" id="changerole'.$UserData['external_id'].'">';
                            echo '<select name="role" form="changerole'.$UserData['external_id'].'">';
                            echo '<option value="user">Użytkownik</option>';
                            echo '<option value="moderator">Moderator</option>';
                            echo '<option value="admin">Administrator</option>';
                            echo '<option value="operator">Operator</option>';
                            echo '<input type="hidden" name="CSRF" value='.$CSRFToken.'>';
                            echo '<input type="hidden" name="upgrade" value="1">';
                            echo '<input type="submit" value="Zapisz" class="role-button">';
                            echo '</select></form></td>';
                            
                            echo '</tr><tr><td class="user-listing-info">';

                            // LOGIN INFO
                            if($CurrentUser['level'] > $UserData['level'] || $CurrentUser['level'] >= 1000) {
                                echo '<b>Ostatnio zalogowany: </b>'.htmlspecialchars($UserData['last_login'], ENT_QUOTES, 'UTF-8').'<br><b>Adres IP: </b>'.htmlspecialchars($UserData['last_ip'], ENT_QUOTES, 'UTF-8');
                            } else {
                                echo '<b>Ostatnio zalogowany: </b>XXXX-XX-XX XX:XX:XX<br><b>Adres IP: </b>XXX.XXX.XXX.XXX';
                            }
                            echo '</td><td class="user-listing-info">';

                            // SHOP COUNT
                            $ShopCounter = $DB -> prepare("SELECT COUNT(*) AS count FROM trades WHERE creator = :login");
                            $ShopCounter -> bindParam(':login', $UserData['login']);
                            $ShopCounter -> execute();
                            $TradesCount = $ShopCounter -> fetch(PDO::FETCH_ASSOC);

                            $ShopCounter = $DB -> prepare("SELECT COUNT(*) AS count FROM offers WHERE creator = :login");
                            $ShopCounter -> bindParam(':login', $UserData['login']);
                            $ShopCounter -> execute();
                            $OffersCount = $ShopCounter -> fetch(PDO::FETCH_ASSOC);

                            $ShopCount = (int) $TradesCount['count'] + (int) $OffersCount['count'];
                            echo '<b>Liczba ogłoszeń: </b>'.$ShopCount;
                            echo '</td>';

                            // BAN CONFIG
                            echo '<td class="user-config-ban"><b>Zablokuj konto:</b>';
                            echo '<form action="admin.php?uid='.$UserData['external_id'].'&usersearch='.$_GET['usersearch'].'" method="post">';
                            echo '<input type="text" name="bantime" class="ban-input" placeholder="Czas (godziny)"><br>';
                            echo '<input type="checkbox" name="pernament" value="1"> Pernamentnie?<br>';
                            echo '<input type="hidden" name="CSRF" value='.$CSRFToken.'>';
                            echo '<input type="hidden" name="ban" value="1">';
                            echo '<input type="submit" value="Zapisz" class="ban-button">';
                            echo '</form></td>';
                            
                            echo '</tr></table></div>';

                            $UserData = $UsersQuerry -> fetch(PDO::FETCH_ASSOC);
                        }
                    } catch (throwable $e) {
                        
                    }
                ?>
            </div>
        </div>

        <footer id="basic-footer">
            <span>Dla nowych moderatorów i administratorów zalecane jest dokładne przeczytanie <a href="/documents/regulamin.pdf">regulaminu</a>, oraz <a href="/documents/user-manual.pdf">poradnika adminstratora.</a>.</span>
        </footer>

        <?php
            // error message
            if(!empty($_SESSION['error'])) {
                echo "<div id=\"error-popup\">";
                echo "<button class=\"error-close\" onclick=\"closeError()\">x</button>";
                echo "<p id=\"error-message\">" . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . "</p>";
                echo "</div>";
                unset($_SESSION['error']);
            }
        ?>
    </body>
</html>