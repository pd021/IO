<?php
    // generate captcha on demand
    if(isset($_GET['captcha'])) {
        require("../functions/captcha.php");
        GenerateCaptchaImage();
        exit();
    }

    // if not logged in - redirect to login
    session_start();
    if (!isset($_SESSION['login'])) {
        header("Location: /pages/login.php");
        exit();
    }

    // import CSRF utility
    require("../functions/csrf.php");

    // import filter
    require("../functions/filter.php");

    // logout
    require("../functions/logout.php");
    if(isset($_POST['logout'])) {
        // CSRF check
        if(!CheckCSRF()){
            header("Location: /pages/home.php");
            exit();
        }

        // logout
        Logout();
        exit();
    }

    // database operations
    if(!(isset($_SESSION['error']) && $_SESSION['error'] === "Wystąpił błąd serwera, spróbój ponownie później.")){
        try {
            require("../config/db.php");
            $DB = new PDO("mysql:host=$DBhost;dbname=$DBname", $DBuser, $DBpass);
            $DB -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $Querry = $DB -> prepare("SELECT username, profile_pic, description, password, level, permaban, ban, active, CASE WHEN ban IS NULL THEN 0 ELSE 1 END AS isbanned, extension FROM users LEFT JOIN media ON profile_pic = media_id WHERE login = :login");
            $Querry -> bindParam(':login', $_SESSION['login']);
            $Querry -> execute();
            $Record = $Querry -> fetch(PDO::FETCH_ASSOC);

            $Username = $Record['username'];
            $ProfileImageID = $Record['profile_pic'];
            $ProfileImageExt = $Record['extension'];
            $Description = base64_decode($Record['description']);
            $Password = $Record['password'];

            // is permabanned?
            if($Record['permaban'] != 0) {
                Logout("Konto zostało pernamentnie zbanowane!");
                $DB = null;
                exit();
            }

            // is regular ban or deactivated?
            if($Record['active'] != 1) {
                if(!empty($Record['ban'])) {
                    Logout("Konto jest zbanowane do ".$Record['ban'].".");
                } else {
                    Logout("Konto zostało deaktywowane!");
                }
                $DB = null;
                exit();
            }

            // should the admin panel option be shown?
            if($Record['level'] >= 100) {$Elevated = true;} else {$Elevated = false;}
            if($Record['level'] >= 150) {$Admin = true;} else {$Admin = false;}
            $Userlevel = $Record['level'];


            // if isset get uid use that info instead
            if(isset($_GET['uid'])) {
                $UID = filter_input(INPUT_GET, 'uid', FILTER_SANITIZE_STRING);
                $Querry = $DB -> prepare("SELECT login, username, profile_pic, description, password, level, extension FROM users LEFT JOIN media ON profile_pic = media_id WHERE external_id = :uid");
                $Querry -> bindParam(':uid', $UID);
                $Querry -> execute();
                $Record = $Querry -> fetch(PDO::FETCH_ASSOC);

                if($Record['login'] != $_SESSION['login'] && (!$Admin || $Record['level'] >= $Userlevel)) {
                    $_SESSION['error'] = "Nie masz wystarczających uprawnień!";
                    header("Location: /pages/home.php");
                    exit();
                }

                $Login = $Record['login'];
                $Level = $Record['level'];
                $Username = $Record['username'];
                $ProfileImageID = $Record['profile_pic'];
                $ProfileImageExt = $Record['extension'];
                $Description = base64_decode($Record['description']);
                $Password = $Record['password'];
            }


            // Load profile picture from DB to web server if not already loaded
            $MediaDIR = $_SERVER['DOCUMENT_ROOT'] . '/media/';
            $MediaFile = $MediaDIR . $ProfileImageID . "." . $ProfileImageExt;
            if (!file_exists($MediaFile)) {
                $Querry = $DB -> prepare("SELECT data FROM media WHERE media_id = :id");
                $Querry -> bindParam(':id', $ProfileImageID);
                $Querry -> execute();
                $Record = $Querry -> fetch(PDO::FETCH_ASSOC);
                if ($Record['data']) {
                    file_put_contents($MediaFile, $Record['data']);
                } else {
                    // media not in db?
                    //$_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
                    //$DB = null;
                    //header("Location: /pages/home.php");
                    //exit();
                }
            }
            
            // self profile update
            if(isset($_POST['update']) && !isset($_GET['uid'])) {
                // CSRF check
                if(!CheckCSRF()){
                    $_SESSION['error'] = "Bład formularza! Spróbuj ponownie.";
                    header("Location: /pages/settings.php");
                    exit();
                }

                // Captcha check
                require("../functions/captcha.php");
                if($_POST['captcha'] !== $_SESSION['captcha']){
                    $_SESSION['error'] = "Nieprawidłowy rozwiązanie captcha!";
                    header("Location: /pages/settings.php");
                    exit();
                }

                // Password check
                if(!password_verify($_POST['password-confirm'], $Password)) {
                    $_SESSION['error'] = "Nieprawidłowe hasło!";
                    header("Location: /pages/settings.php");
                    exit();
                }

                // New passwords are the same
                if($_POST['new-password'] != $_POST['new-password-confirm']) {
                    $_SESSION['error'] = "Nowe hasła nie są zgodne!";
                    header("Location: /pages/settings.php");
                    exit();
                }

                // Upload new media
                if (isset($_FILES['profile-pic']) && $_FILES['profile-pic']['error'] !== UPLOAD_ERR_NO_FILE) {
                    if ($_FILES['profile-pic']['error'] !== UPLOAD_ERR_OK) {
                        $_SESSION['error'] = "Wystąpił błąd podczas przesyłania plików!";
                        $DB = null;
                        header("Location: /pages/settings.php");
                        exit();
                    }
                    // Get the file details
                    $MediaFileTMP = $_FILES['profile-pic']['tmp_name'];
                    $MediaFileTMPSize = $_FILES['profile-pic']['size'];

                    // check extension
                    $FileInfo = finfo_open(FILEINFO_MIME_TYPE); 
                    $MediaFileTMPExt = finfo_file($FileInfo, $MediaFileTMP);
                    finfo_close($FileInfo);

                    // Allowed image types
                    $ExtWhitelist = [
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/svg+xml' => 'svg',
                        'image/gif' => 'gif'
                    ];

                    // check extension is allowed and file is < 4MB
                    if (array_key_exists($MediaFileTMPExt, $ExtWhitelist) && @getimagesize($MediaFileTMP) && $MediaFileTMPSize <= 4 * 1024 * 1024) {
                        // Read the file content
                        $MediaFileData = file_get_contents($MediaFileTMP);

                        // upload to db
                        $Querry = $DB -> prepare("INSERT INTO media (uploaded_by, uploaded_on, data, extension) VALUES (:login, NOW(), :data, :ext)");
                        $Querry -> bindParam(':login', $_SESSION['login']);
                        $Querry -> bindParam(':data', $MediaFileData, PDO::PARAM_LOB);
                        $Querry -> bindParam(':ext', $ExtWhitelist[$MediaFileTMPExt]);
                        $Querry -> execute();

                        // set old picture to delete
                        $ProfileImageIDOld = $ProfileImageID;
                        $ProfileImageID = $DB -> lastInsertId();

                    } else {
                        $_SESSION['error'] = "Niedozwolony format lub rozmiar pliku (max. 4MB)!";
                        $DB = null;
                        header("Location: /pages/settings.php");
                        exit();
                    }
                }

                // Update data
                if(isset($_POST['username']) && !empty($_POST['username'])) {$Username = Filter(filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING));}
                if(isset($_POST['new-password']) && !empty($_POST['new-password'])) {$Password = password_hash(filter_input(INPUT_POST, 'new-password', FILTER_SANITIZE_STRING), PASSWORD_BCRYPT, ["cost" => 14]);}
                if(isset($_POST['description']) && !empty($_POST['description'])) {$Description = base64_encode(Filter(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING)));}

                # Save changes to DB
                $Querry = $DB -> prepare("UPDATE users SET username = :user, description = :desc, password = :pass, profile_pic = :pic WHERE login = :login");
                $Querry -> bindParam(':user', $Username);
                $Querry -> bindParam(':desc', $Description);
                $Querry -> bindParam(':pass', $Password);
                $Querry -> bindParam(':pic', $ProfileImageID);
                $Querry -> bindParam(':login', $_SESSION['login']);
                $Querry -> execute();

                // delete old pic
                if(isset($ProfileImageIDOld)) {
                    $Querry = $DB -> prepare("DELETE FROM media WHERE media_id = :id");
                    $Querry -> bindParam(':id', $ProfileImageIDOld);
                    $Querry -> execute();
                }
                
                $DB = null;
                header("Location: /pages/settings.php");
                exit();
            }

            // alternative profile update
            if(isset($_POST['update']) && isset($_GET['uid']) && !empty($_GET['uid'])) {
                // CSRF check
                if(!CheckCSRF()){
                    $_SESSION['error'] = "Bład formularza! Spróbuj ponownie.";
                    header("Location: /pages/settings.php");
                    exit();
                }

                // Captcha check
                require("../functions/captcha.php");
                if($_POST['captcha'] !== $_SESSION['captcha']){
                    $_SESSION['error'] = "Nieprawidłowy rozwiązanie captcha!";
                    header("Location: /pages/settings.php");
                    exit();
                }

                // New passwords are the same
                if($_POST['new-password'] != $_POST['new-password-confirm']) {
                    $_SESSION['error'] = "Nowe hasła nie są zgodne!";
                    header("Location: /pages/settings.php");
                    exit();
                }

                // additional permission check
                if($Login != $_SESSION['login'] && (!$Admin || $Level >= $Userlevel)) {
                    $_SESSION['error'] = "Nie masz wystarczających uprawnień!";
                    header("Location: /pages/home.php");
                    exit();
                }

                // Upload new media
                if (isset($_FILES['profile-pic']) && $_FILES['profile-pic']['error'] !== UPLOAD_ERR_NO_FILE) {
                    if ($_FILES['profile-pic']['error'] !== UPLOAD_ERR_OK) {
                        $_SESSION['error'] = "Wystąpił błąd podczas przesyłania plików!";
                        $DB = null;
                        header("Location: /pages/settings.php");
                        exit();
                    }
                    // Get the file details
                    $MediaFileTMP = $_FILES['profile-pic']['tmp_name'];
                    $MediaFileTMPSize = $_FILES['profile-pic']['size'];

                    // check extension
                    $FileInfo = finfo_open(FILEINFO_MIME_TYPE); 
                    $MediaFileTMPExt = finfo_file($FileInfo, $MediaFileTMP);
                    finfo_close($FileInfo);

                    // Allowed image types
                    $ExtWhitelist = [
                        'image/jpeg' => 'jpg',
                        'image/png' => 'png',
                        'image/svg+xml' => 'svg',
                        'image/gif' => 'gif'
                    ];

                    // check extension is allowed and file is < 4MB
                    if (array_key_exists($MediaFileTMPExt, $ExtWhitelist) && @getimagesize($MediaFileTMP) && $MediaFileTMPSize <= 4 * 1024 * 1024) {
                        // Read the file content
                        $MediaFileData = file_get_contents($MediaFileTMP);

                        // upload to db
                        $Querry = $DB -> prepare("INSERT INTO media (uploaded_by, uploaded_on, data, extension) VALUES (:login, NOW(), :data, :ext)");
                        $Querry -> bindParam(':login', $_SESSION['login']); // by design uploaded by person editing the profile
                        $Querry -> bindParam(':data', $MediaFileData, PDO::PARAM_LOB);
                        $Querry -> bindParam(':ext', $ExtWhitelist[$MediaFileTMPExt]);
                        $Querry -> execute();

                        // set old picture to delete
                        $ProfileImageIDOld = $ProfileImageID;
                        $ProfileImageID = $DB -> lastInsertId();

                    } else {
                        $_SESSION['error'] = "Niedozwolony format lub rozmiar pliku (max. 4MB)!";
                        $DB = null;
                        header("Location: /pages/settings.php");
                        exit();
                    }
                }

                // Update data
                if(isset($_POST['username']) && !empty($_POST['username'])) {$Username = Filter(filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING));}
                if(isset($_POST['new-password']) && !empty($_POST['new-password'])) {$Password = password_hash(filter_input(INPUT_POST, 'new-password', FILTER_SANITIZE_STRING), PASSWORD_BCRYPT, ["cost" => 14]);}
                if(isset($_POST['description']) && !empty($_POST['description'])) {$Description = base64_encode(Filter(filter_input(INPUT_POST, 'description', FILTER_SANITIZE_STRING)));}

                # Save changes to DB
                $Querry = $DB -> prepare("UPDATE users SET username = :user, description = :desc, password = :pass, profile_pic = :pic WHERE login = :login");
                $Querry -> bindParam(':user', $Username);
                $Querry -> bindParam(':desc', $Description);
                $Querry -> bindParam(':pass', $Password);
                $Querry -> bindParam(':pic', $ProfileImageID);
                $Querry -> bindParam(':login', $Login); // set user instead of the editor
                $Querry -> execute();

                // delete old pic
                if(isset($ProfileImageIDOld)) {
                    $Querry = $DB -> prepare("DELETE FROM media WHERE media_id = :id");
                    $Querry -> bindParam(':id', $ProfileImageIDOld);
                    $Querry -> execute();
                }
                
                $DB = null;
                header("Location: /pages/settings.php?uid=" . $UID);
                exit();
            }

        } catch (PDOException $e) {
            $_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
            //$_SESSION['error'] = $e;
            header("Location: /pages/settings.php");
            exit();
        }
    }
    $DB = null;

    // set image path
    if (empty($ProfileImageID)) {
        $ImagePath = "/assets/null.png";
    } else {
        $ImagePath = "/media/" . $ProfileImageID.".".$ProfileImageExt;
    }

    //generate CSRF token
    $CSRFToken = GenerateCSRF();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="settings panel profile user">
        <link rel="icon" href="/assets/favicon64.ico" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/assets/style_common.css">
        <link rel="stylesheet" href="/assets/style_settings.css">
        <meta http-equiv="Cache-Control" content="max-age=3600">
        <title>Ustawienia profilu</title>
        <script>
            function closeError() {
                var popup = document.getElementById('error-popup');
                popup.style.display = 'none';
            }
        </script>
    </head>
    <body>
        <nav class="menu-bar">
            <a href="/pages/forum.php"><div class="menu-item">Forum</div></a>
            <a href="/pages/chat.php"><div class="menu-item">Chat</div></a>
            <a href="/pages/shop.php"><div class="menu-item">Sklep</div></a>
            <?php
                if($Elevated) {
                    echo '<a href="/pages/admin.php"><div class="menu-item">Aministracja</div></a>';
                }
            ?>
            <a href="/pages/home.php" style="position: absolute; right: 9vw;"><div class="menu-item">Strona domowa</div></a>
            <form action="settings.php" method="post" class="logout">
                <input type="hidden" name="logout" value="1">
                <input type="hidden" name="CSRF" value="<?php echo $CSRFToken;?>">
                <input type="submit" id="logout-button" value="Wyloguj się">
            </form>
        </nav>

        <div id="profile-container">
            <?php
                if(isset($_GET['uid'])) {
                    $FormAction = "settings.php?uid=" . $_GET['uid'];
                } else {
                    $FormAction = "settings.php";
                }
            ?>
            <form action="<?php echo $FormAction; ?>" method="post" enctype="multipart/form-data">
                <table>
                    <tr>
                        <td rowspan="5" id="profile-img-container">
                            <img src="<?php echo $ImagePath ?>" alt="404" id="profile-img"/>
                            <br>
                            Nowe zdjęcie:
                            <br>
                            <input type="file" name="profile-pic">
                        </td>
                    </tr>
                    <td id="settings-title">Ustawienia profilu</td>
                        <tr><td><input type="text" name="username" class="profile-field" placeholder="Nazwa użytkownika" value="<?php echo $Username; ?>"></td></tr>
                        <tr><td><input type="password" name="new-password" class="profile-field" placeholder="Nowe hasło"></td></td></tr>
                        <tr><td><input type="password" name="new-password-confirm" class="profile-field" placeholder="Potwierdź hasło"></td></tr>
                        <tr>
                            <td id="description-container">
                                Opis profilu:
                                <br>
                                <textarea name="description" id="description"><?php echo htmlspecialchars($Description, ENT_QUOTES, 'UTF-8') ?></textarea>
                            </td>
                            <td>
                                <img src="?captcha=" alt="???" id="captcha-img" onclick="document.getElementById('captcha-img').src='?captcha='+Math.random();"/>
                                <br>
                                <input type="text" name="captcha" class="confirm-field" placeholder="Weryfikacja captcha">
                                <br>
                                <?php
                                    if(!isset($_GET['uid'])) {
                                        echo '<input type="password" name="password-confirm" class="confirm-field" placeholder="Stare hasło / potwierdź zmiany">';
                                    }
                                ?>
                                <br>
                                <input type="hidden" name="update" value="1">
                                <input type="hidden" name="CSRF" value="<?php echo $CSRFToken;?>">
                                <input type="submit" id="save-button" value="Zapisz zmiany">
                            </td>
                        </tr>
                </table>
            </form>
        </div>
        
        <?php
            // error message
            if(!empty($_SESSION['error'])) {
                echo "<div id=\"error-popup\">";
                echo "<button class=\"error-close\" onclick=\"closeError()\">x</button>";
                echo "<p id=\"error-message\">" . htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') . "</p>";
                echo "</div>";
                unset($_SESSION['error']);
            }
        ?>
    </body>
</html>