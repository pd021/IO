<?php
    // generate captcha on demand
    if(isset($_GET['captcha'])) {
        require("../functions/captcha.php");
        GenerateCaptchaImage();
        exit();
    }

    // if already logged in, redirect to home
    session_start();
    if (isset($_SESSION['login'])) {
        header("Location: /pages/home.php");
        exit();
    }

    // import CSRF utility
    require("../functions/csrf.php");

    // import filter
    require("../functions/filter.php");

    // attempt registration
    if(isset($_POST['CSRF'])) {
        // field checks
        if(!isset($_POST['login'])){
            $_SESSION['error'] = "Wymagane pole - login.";
            header("Location: /pages/register.php");
            exit();
        }
        if(!isset($_POST['username'])){
            $_SESSION['error'] = "Wymagane pole - nazwa użytkownika.";
            header("Location: /pages/register.php");
            exit();
        }
        if(!isset($_POST['password'])){
            $_SESSION['error'] = "Wymagane pole - hasło.";
            header("Location: /pages/register.php");
            exit();
        }
        if($_POST['password'] !== $_POST['password-confirm']){
            $_SESSION['error'] = "Hasła nie są zgodne.";
            header("Location: /pages/register.php");
            exit();
        }
        if(!isset($_POST['captcha'])){
            $_SESSION['error'] = "Wymagane pole - captcha.";
            header("Location: /pages/register.php");
            exit();
        }

        // CSRF check
        if(!CheckCSRF()){
            $_SESSION['error'] = "Bład formularza! Spróbuj ponownie.";
            header("Location: /pages/register.php");
            exit();
        }

        // captcha check
        if($_POST['captcha'] !== $_SESSION['captcha']){
            $_SESSION['error'] = "Nieprawidłowy rozwiązanie captcha!";
            header("Location: /pages/register.php");
            exit();
        }

        try {
            $Login = filter_input(INPUT_POST, 'login', FILTER_SANITIZE_STRING);
            $Username = Filter(filter_input(INPUT_POST, 'username', FILTER_SANITIZE_STRING));
            $Password = filter_input(INPUT_POST, 'password', FILTER_SANITIZE_STRING);

            require("../config/db.php");
            $DB = new PDO("mysql:host=$DBhost;dbname=$DBname", $DBuser, $DBpass);
            $DB -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            // check if account with the same login exists
            $Querry = $DB -> prepare("SELECT COUNT(*) AS exist FROM users WHERE login = :login");
            $Querry -> bindParam(':login', $Login);
            $Querry -> execute();
            $Record = $Querry -> fetch(PDO::FETCH_ASSOC);

            if($Record['exist'] != 0){
                $_SESSION['error'] = "Konto z podanym loginem już istnieje!";
                header("Location: /pages/register.php");
                exit();
            }

            // generate next external id
            $Querry = $DB -> prepare("SELECT MAX(external_id) AS max FROM users;");
            $Querry -> execute();
            $Record = $Querry -> fetch(PDO::FETCH_ASSOC);
            $ExternalID = $Record['max'] + 1;

            $Querry = $DB -> prepare("INSERT INTO users (login, username, password, level, last_ip, active, ban, permaban, ircbanned, external_id) VALUES (:login, :username, :password, 0, NULL, true, NULL, false, false, :extid);");
            $Querry -> bindParam(':login', $Login);
            $Querry -> bindParam(':username', $Username);
            $PasswordENC = password_hash($Password, PASSWORD_BCRYPT, ["cost" => 14]);
            $Querry -> bindParam(':password', $PasswordENC);
            $Querry -> bindParam(':extid', $ExternalID);
            $Querry -> execute();
            $Record = $Querry -> fetch(PDO::FETCH_ASSOC);

            // done
            $DB = null;
            $_SESSION['error'] = "Konto utworzono pomyślnie!";
            header("Location: /pages/login.php");
            exit();

        } catch (PDOException $e) {
            $_SESSION['error'] = "Wystąpił błąd serwera, spróbój ponownie później.";
            //$_SESSION['error'] = $e;
            header("Location: /pages/register.php");
            exit();
        }
    }
    $DB = null;

    //generate CSRF token
    $CSRFToken = GenerateCSRF();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta charset="UTF-8">
        <meta name="description" content="login panel">
        <link rel="icon" href="/assets/favicon64.ico" type="image/x-icon">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="/assets/style_common.css">
        <link rel="stylesheet" href="/assets/style_register.css">
        <meta http-equiv="Cache-Control" content="max-age=3600">
        <title>Rejestracja</title>
    </head>
    <body>
        <div id="register-container">
            <form action="/pages/register.php" method="post">
                <table>
                    <tr>
                        <td><input type="text" name="login" placeholder="Login" required></td>
                    </tr>
                    <tr>
                        <td><input type="text" name="username" placeholder="Nazwa użytkownika" required></td>
                    </tr>
                    <tr>
                        <td><input type="password" name="password" placeholder="Hasło" required></td>
                    </tr>
                    <tr>
                        <td><input type="password" name="password-confirm" placeholder="Potwierdź hasło" required></td>
                    </tr>
                    <tr>
                        <td><img src="?captcha=" alt="???" id="captcha_img" onclick="document.getElementById('captcha_img').src='?captcha='+Math.random();" style="width:80%;" /></td>
                    </tr>
                    <tr>
                        <td><input type="text" id="captcha" name="captcha" placeholder="Captcha" required></td>
                    </tr>
                    <?php
                        if(isset($_SESSION['error'])){
                            echo('
                                <tr>
                                    <td><span class="error">'. htmlspecialchars($_SESSION['error'], ENT_QUOTES, 'UTF-8') .'</span></td>
                                </tr>
                            ');
                            unset($_SESSION['error']);
                        }
                    ?>
                    <tr>
                        <td>
                            <input type="hidden" name="CSRF" value="<?php echo $CSRFToken;?>">
                            <input type="submit" value="Rejestracja">
                        </td>
                    </tr>
                    <tr>
                        <td><a href="/pages/login.php"><p id="login-link">Zaloguj się</p></a></td>
                    </tr>
                </table>
            </form>
        </div>

        <footer id="basic-footer">
            <span>Dla nowych użytkowników zalecane jest przeczytanie <a href="/documents/regulamin.pdf">regulaminu</a>, oraz <a href="/documents/user-manual.pdf">poradnik nowego użytkownika</a>.</span>
        </footer>
    </body>
</html>