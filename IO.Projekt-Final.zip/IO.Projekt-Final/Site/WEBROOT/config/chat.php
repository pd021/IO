<?php
    $UpdateDelay = 2;
    $LastNMessages = 50;
    $MaxMessagesInUpdate = 50;
?>