<?php
    $Dictionary = [
        'marco!' => 'polo!'
    ];
?>
