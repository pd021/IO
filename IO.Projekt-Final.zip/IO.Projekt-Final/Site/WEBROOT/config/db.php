<?php
    $DBhost = 'localhost';
    $DBuser = 'dbuser';
    $DBpass = "@DBpass64";
    $DBname = 'forum';
?>