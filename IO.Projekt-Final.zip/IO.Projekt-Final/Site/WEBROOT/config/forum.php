<?php
    $PostsPerPage = 10;
    $CommentsPerPage = 10;
    $MaxFileSize = 128 * 1024 * 1024; // 128MB
    $BannedExtensions = [
        'php', 'php3', 'php4', 'php5', 'phtml', 
        'exe', 'bat', 'cmd', 'sh', 'js', 'html', 'htm', 
        'pl', 'py', 'asp', 'aspx', 'cgi'
    ];
?>