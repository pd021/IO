<?php
    $TradesPerPage = 5;
    $OffersPerPage = 5;
?>