# Create forum database
CREATE DATABASE forum;

# Create database user for site
CREATE USER 'dbuser'@'localhost' IDENTIFIED BY '@DBpass64';
GRANT ALL PRIVILEGES ON forum.* TO 'dbuser'@'localhost';
FLUSH PRIVILEGES;

# Setup tables ------------------------------------------------
USE forum;

# USERS table
CREATE TABLE users (
    login VARCHAR(64) PRIMARY KEY,
    username VARCHAR(64) NOT NULL,
    description TEXT DEFAULT NULL,
    profile_pic INT DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    level INT DEFAULT 0 NOT NULL,
    last_ip TEXT DEFAULT NULL,
    last_login DATETIME DEFAULT NULL,
    active BOOLEAN DEFAULT true,
    ban DATETIME DEFAULT NULL,
    permaban BOOLEAN DEFAULT false,
    ircbanned BOOLEAN DEFAULT false,
    external_id INT NOT NULL DEFAULT 0
);

# MEDIA table
CREATE TABLE media (
    media_id INT AUTO_INCREMENT PRIMARY KEY,
    uploaded_by VARCHAR(64),
    uploaded_on DATETIME DEFAULT NULL,
    data LONGBLOB NOT NULL,
    extension VARCHAR(16) DEFAULT NULL,
    CONSTRAINT fk_uploaded_by FOREIGN KEY (uploaded_by) REFERENCES users(login)
);
ALTER TABLE users ADD CONSTRAINT fk_profile_pic FOREIGN KEY (profile_pic) REFERENCES media(media_id);

# NEWS table
CREATE TABLE news (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    creator VARCHAR(64) NOT NULL,
    created_date DATETIME NOT NULL,
    title TEXT NOT NULL,
    body MEDIUMTEXT DEFAULT NULL,
    edit_level INT NOT NULL DEFAULT 0,
    edit_date DATETIME DEFAULT NULL,
    edited_by VARCHAR(64) DEFAULT NULL,
    FOREIGN KEY (creator) REFERENCES users(login),
    FOREIGN KEY (edited_by) REFERENCES users(login)
);

# POSTS (forum) table
CREATE TABLE posts (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    creator VARCHAR(64) NOT NULL,
    created_date DATETIME NOT NULL,
    title TEXT NOT NULL,
    body MEDIUMTEXT DEFAULT NULL,
    edit_level INT NOT NULL DEFAULT 0,
    edit_date DATETIME DEFAULT NULL,
    edited_by VARCHAR(64) DEFAULT NULL,
    FOREIGN KEY (creator) REFERENCES users(login),
    FOREIGN KEY (edited_by) REFERENCES users(login)
);

# COMMENTS (to posts) table
CREATE TABLE comments (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    creator VARCHAR(64) NOT NULL,
    created_date DATETIME NOT NULL,
    body MEDIUMTEXT DEFAULT NULL,
    FOREIGN KEY (creator) REFERENCES users(login),
    FOREIGN KEY (post_id) REFERENCES posts(ID)
);

# MEDIA IN POSTS (forum) table
CREATE TABLE mediaINposts (
    post_id INT NOT NULL,
    media_id INT NOT NULL,
    PRIMARY KEY (post_id, media_id),
    FOREIGN KEY (post_id) REFERENCES posts(ID)
);

# IRC LOG table
CREATE TABLE irclog (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    sender VARCHAR(64) NOT NULL,
    timestamp DATETIME NOT NULL,
    message MEDIUMTEXT NOT NULL,
    deleted BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (sender) REFERENCES users(login)
);

# TRADE OFFERS table
CREATE TABLE trades (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    creator VARCHAR(64) NOT NULL,
    created_date DATETIME NOT NULL,
    title TEXT NOT NULL,
    body MEDIUMTEXT DEFAULT NULL,
    editor VARCHAR(64) DEFAULT NULL,
    edit_date DATETIME DEFAULT NULL,
    state TEXT DEFAULT 'OPEN',
    offer_id INT DEFAULT NULL,
    FOREIGN KEY (creator) REFERENCES users(login),
    FOREIGN KEY (editor) REFERENCES users(login)
);

# MEDIA IN TRADES (SHOP)
CREATE TABLE mediaINtrades (
    trade_id INT NOT NULL,
    media_id INT NOT NULL,
    PRIMARY KEY (trade_id, media_id),
    FOREIGN KEY (trade_id) REFERENCES trades(ID),
);

# TRADE OFFERS
CREATE TABLE offers (
    ID INT AUTO_INCREMENT PRIMARY KEY,
    trade_id INT NOT NULL,
    creator VARCHAR(64) NOT NULL,
    created_date DATETIME NOT NULL,
    body MEDIUMTEXT DEFAULT NULL,
    FOREIGN KEY (trade_id) REFERENCES trades(ID),
    FOREIGN KEY (creator) REFERENCES users(login)
);

# MEDIA IN OFFERS
CREATE TABLE mediaINoffers (
    offer_id INT NOT NULL,
    media_id INT NOT NULL,
    PRIMARY KEY (offer_id, media_id),
    FOREIGN KEY (offer_id) REFERENCES offers(ID)
);


# default OPERATOR user, password is "OPERATOR"
INSERT INTO users (login, username, password, level, last_ip, last_login, active, ban, permaban, ircbanned, external_id)
VALUES ('OPERATOR', 'OPERATOR', '$2a$14$54aIcPrVpqKC5Vucyh8atei0IJLEN7jWpUvCcpsFv7dH5XDMa4FtK', 1000, NULL, NULL, true, NULL, false, false, 1);